const crypto = require('crypto');

const KEYS = {
  v1: process.env.E2E_KEY_V1 && Buffer.from(process.env.E2E_KEY_V1, 'base64'),
  v2: process.env.E2E_KEY_V2 && Buffer.from(process.env.E2E_KEY_V2, 'base64'),
};
// FIX: HMAC_SECRET is hex string, not base64
const HMAC = process.env.HMAC_SECRET && Buffer.from(process.env.HMAC_SECRET, 'utf8');
const TS_WINDOW = 120;

// PROMPTV3 S3: LRU-capped nonce cache (~100k entries, FIFO eviction by Map insertion order)
const NONCE_LIMIT = 100000;
const seenNonces = new Map();

function purge() {
  const now = Date.now();
  for (const [nonce, expiry] of seenNonces) {
    if (expiry < now) seenNonces.delete(nonce); else break; // ordered by insertion
  }
  // Hard cap
  while (seenNonces.size > NONCE_LIMIT) {
    const k = seenNonces.keys().next().value;
    seenNonces.delete(k);
  }
}

function decrypt(env) {
  const key = KEYS[env.kid];
  if (!key) throw new Error('bad_kid');
  const iv = Buffer.from(env.iv, 'hex');
  const tag = Buffer.from(env.tag, 'hex');
  const aad = Buffer.from(`soulddv4|${env.ts}|${env.kid}`);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAAD(aad);
  decipher.setAuthTag(tag);
  const ciphertext = Buffer.from(env.ct, 'base64');
  const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return JSON.parse(plaintext.toString('utf8'));
}

function encrypt(payload, kid = 'v1') {
  const key = KEYS[kid];
  if (!key) throw new Error('bad_kid');
  const ts = Math.floor(Date.now() / 1000);
  const iv = crypto.randomBytes(12);
  const aad = Buffer.from(`soulddv4|${ts}|${kid}`);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(aad);
  const plaintext = Buffer.from(JSON.stringify(payload));
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { v: 1, iv: iv.toString('hex'), ct: ciphertext.toString('base64'), tag: tag.toString('hex'), ts, kid };
}

function verifySig(env, sig) {
  if (!HMAC || !sig) return false;
  const data = `${env.iv}${env.ct}${env.tag}${env.ts}`;
  const hmac = crypto.createHmac('sha256', HMAC);
  const expected = hmac.update(data).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig)); }
  catch { return false; }
}

function replayOk(nonce) {
  purge();
  if (seenNonces.has(nonce)) return false;
  seenNonces.set(nonce, Date.now() + 300_000);
  if (seenNonces.size > NONCE_LIMIT) {
    const k = seenNonces.keys().next().value;
    seenNonces.delete(k);
  }
  return true;
}

module.exports = { decrypt, encrypt, verifySig, replayOk, TS_WINDOW };
