#!/usr/bin/env node
/**
 * Generate integrity.json with SHA-256 hashes of monitored files.
 * Run once after a clean deploy:
 *   node scripts/gen-integrity.js
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const FILES = [
  'app.js',
  'init-db.js',
  'middleware/auth.js',
  'middleware/security.js',
  'routes/auth.js',
  'routes/keys.js',
  'routes/users.js',
  'routes/promos.js',
  'routes/dashboard.js',
  'db/database.js',
];

const out = {};
for (const rel of FILES) {
  const fp = path.join(ROOT, rel);
  if (!fs.existsSync(fp)) { console.warn('skip (missing):', rel); continue; }
  out[rel] = crypto.createHash('sha256').update(fs.readFileSync(fp)).digest('hex');
}
fs.writeFileSync(path.join(ROOT, 'integrity.json'), JSON.stringify(out, null, 2));
console.log('integrity.json written with', Object.keys(out).length, 'entries');
