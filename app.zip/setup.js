const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');
const path = require('path');

console.log('🔧 Starting setup...');

const dbPath = path.join(__dirname, 'panel.db');
console.log('📁 Database path:', dbPath);

try {
    const db = new Database(dbPath);
    console.log('✅ Database connected');

    // Create users table
    db.exec(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    console.log('✅ Users table ready');

    // Hash password
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    console.log('✅ Password hashed');

    // Insert admin
    const stmt = db.prepare(`INSERT OR REPLACE INTO users (username, password, role) VALUES (?, ?, ?)`);
    const info = stmt.run('admin', hashedPassword, 'admin');
    console.log('✅ Admin inserted, changes:', info.changes);

    // Verify
    const check = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
    console.log('✅ Verification result:', check);

    db.close();
    console.log('✅ Setup complete!');
    console.log('📝 Username: admin');
    console.log('🔑 Password: admin123');

} catch (error) {
    console.error('❌ Error:', error.message);
}