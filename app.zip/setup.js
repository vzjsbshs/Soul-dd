const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');
const path = require('path');

const dbPath = path.join(__dirname, 'panel.db');
const db = new Database(dbPath);

const hashedPassword = bcrypt.hashSync('admin123', 10);

db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

const stmt = db.prepare(`INSERT OR REPLACE INTO users (username, password, role) VALUES (?, ?, ?)`);
stmt.run('admin', hashedPassword, 'admin');

console.log('✅ Admin user created!');
console.log('📝 Username: admin');
console.log('🔑 Password: admin123');

// Verify
const check = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
console.log('✅ Verification:', check);

db.close();