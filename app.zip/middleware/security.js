/**
 * Panel security middlewares (PROMPTV4 fixes):
 *  - honeypot for scanner paths
 *  - HMAC-SHA256 verification for /api/keys/verify
 *  - brute-force IP blocker for /api/keys/verify
 *  - FIXED: Use cf-connecting-ip instead of req.ip (V11)
 */
const crypto = require('crypto');

const HMAC_SECRET = process.env.HMAC_SECRET || '';
const HMAC_REQUIRED = String(process.env.HMAC_REQUIRED || 'true').toLowerCase() === 'true'; // PROMPTV4: default true

// In-memory brute force tracker
const failsByIp = new Map();   // ip -> [timestamps]
const blockedIps = new Map();  // ip -> until_ts
const FAIL_WINDOW_MS = 60 * 1000;
const BLOCK_THRESHOLD = 10;
const BLOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const HOUR_MS = 60 * 60 * 1000;

// PROMPTV4 N11 FIX: Extract real IP using CF-Connecting-IP
function getRealIp(req) {
  return req.get('cf-connecting-ip') || req.get('x-forwarded-for') || req.ip;
}

// PROMPTV4 V11 FIX: Accept req object instead of just IP string
function recordVerifyFail(req) {
  const ip = getRealIp(req);
  const now = Date.now();
  const arr = (failsByIp.get(ip) || []).filter(ts => now - ts < HOUR_MS);
  arr.push(now);
  failsByIp.set(ip, arr);
  // last-minute count
  const lastMin = arr.filter(ts => now - ts < FAIL_WINDOW_MS).length;
  if (lastMin >= BLOCK_THRESHOLD) {
    blockedIps.set(ip, now + BLOCK_DURATION_MS);
    if (global.securityLogger) {
      global.securityLogger.warn(`[brute-force] IP ${ip} blocked for 15m (${lastMin} bad keys/min)`);
    }
  }
}

function isBlocked(req) {
  const ip = getRealIp(req);
  const until = blockedIps.get(ip);
  if (!until) return false;
  if (Date.now() > until) { blockedIps.delete(ip); return false; }
  return true;
}

function blockMiddleware(req, res, next) {
  if (isBlocked(req)) {
    return res.status(429).json({ valid: false, reason: 'rate_limited' });
  }
  next();
}

function recentVerifyFails() {
  const now = Date.now();
  let total = 0;
  for (const [, arr] of failsByIp) total += arr.filter(ts => now - ts < HOUR_MS).length;
  return total;
}

/**
 * HMAC-SHA256 verify for /api/keys/verify.
 * PROMPTV4 V1 FIX: Enforce HMAC by default (HMAC_REQUIRED=true)
 *   App sends header: X-Request-Sig: <hex hmac of "<key>|<device_id>" using HMAC_SECRET>
 * If HMAC_REQUIRED=false, missing/invalid sig is logged but request proceeds.
 */
function hmacVerify(req, res, next) {
  if (!HMAC_SECRET) {
    if (global.securityLogger) global.securityLogger.error('[hmac] HMAC_SECRET not set!');
    return res.status(500).json({ valid: false, reason: 'server_error' });
  }
  
  const sig = req.get('X-Request-Sig') || req.get('x-request-sig') || '';
  const key = req.query.key || '';
  const did = req.query.device_id || '';
  
  if (!sig) {
    if (HMAC_REQUIRED) {
      if (global.securityLogger) global.securityLogger.warn(`[hmac] missing signature from ${getRealIp(req)}`);
      return res.status(401).json({ valid: false, reason: 'missing_signature' });
    }
    return next();
  }
  
  const expected = crypto.createHmac('sha256', HMAC_SECRET)
    .update(`${key}|${did}`).digest('hex');
  let ok = false;
  try {
    ok = sig.length === expected.length &&
         crypto.timingSafeEqual(Buffer.from(sig, 'hex'), Buffer.from(expected, 'hex'));
  } catch (_) { ok = false; }
  
  if (!ok) {
    if (global.securityLogger) global.securityLogger.warn(`[hmac] bad signature from ${getRealIp(req)}`);
    if (HMAC_REQUIRED) return res.status(401).json({ valid: false, reason: 'bad_signature' });
  }
  next();
}

const HONEYPOT_PATHS = ['/admin', '/wp-admin', '/wp-login.php', '/phpmyadmin', '/.env', '/.git', '/manager/html'];

function honeypot(req, res, next) {
  const p = req.path.toLowerCase();
  if (HONEYPOT_PATHS.some(h => p === h || p.startsWith(h + '/'))) {
    if (global.securityLogger) global.securityLogger.warn(`[honeypot] ${getRealIp(req)} -> ${req.path} ua="${req.get('user-agent') || ''}"`);
    return res.status(404).send('Not Found');
  }
  next();
}

module.exports = {
  honeypot,
  hmacVerify,
  blockMiddleware,
  recordVerifyFail,
  isBlocked,
  recentVerifyFails,
  getRealIp,
};
