const jwt = require('jsonwebtoken');
const { db } = require('../db/database-v4');

// FIX A5: Throw error if JWT_SECRET is not set or is weak
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET === 'dev_secret_change_me' || SECRET.length < 32) {
  throw new Error('FATAL: JWT_SECRET must be set in .env and must be at least 32 characters');
}

function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, role: user.role, tv: user.token_version || 0 },
    SECRET,
    { expiresIn: '7d' }
  );
}

function authRequired(req, res, next) {
  let token = req.cookies && req.cookies.token;
  if (!token && req.headers.authorization) {
    const parts = req.headers.authorization.split(' ');
    if (parts.length === 2 && parts[0] === 'Bearer') token = parts[1];
  }
  if (!token) return res.status(401).json({ error: 'unauthenticated' });
  try {
    const payload = jwt.verify(token, SECRET);
    const user = db.prepare('SELECT id, username, role, status, token_version, must_change_password FROM users WHERE id = ?').get(payload.id);
    if (!user) return res.status(401).json({ error: 'user_not_found' });
    if (user.status !== 'approved') return res.status(403).json({ error: 'not_approved', status: user.status });
    if ((user.token_version || 0) !== (payload.tv || 0)) return res.status(401).json({ error: 'session_revoked' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid_token' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'unauthenticated' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'forbidden' });
    next();
  };
}

function pageAuth(req, res, next) {
  let token = req.cookies && req.cookies.token;
  if (!token) return res.redirect('/login');
  try {
    const payload = jwt.verify(token, SECRET);
    const user = db.prepare('SELECT id, username, role, status, token_version, must_change_password FROM users WHERE id = ?').get(payload.id);
    if (!user || user.status !== 'approved' || (user.token_version || 0) !== (payload.tv || 0)) {
      res.clearCookie('token');
      return res.redirect('/login');
    }
    req.user = user;
    next();
  } catch (e) {
    res.clearCookie('token');
    return res.redirect('/login');
  }
}

module.exports = { signToken, authRequired, requireRole, pageAuth, SECRET };
