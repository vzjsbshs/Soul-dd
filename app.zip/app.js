require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// DATABASE
// ============================================================
const db = new Database('panel.db');

// Create tables
db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT DEFAULT 'user'
    );
    
    CREATE TABLE IF NOT EXISTS license_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_value TEXT UNIQUE,
        status TEXT DEFAULT 'active',
        expires_at DATETIME
    );
`);

// Create admin if not exists
const admin = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
if (!admin) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)").run('admin', hash, 'admin');
    console.log('✅ Admin created: admin / admin123');
}

// Create test keys
const keyCount = db.prepare("SELECT COUNT(*) as count FROM license_keys").get();
if (keyCount.count === 0) {
    db.prepare("INSERT INTO license_keys (key_value) VALUES (?)").run('SOUL-KEY-001');
    db.prepare("INSERT INTO license_keys (key_value) VALUES (?)").run('SOUL-KEY-002');
    db.prepare("INSERT INTO license_keys (key_value) VALUES (?)").run('SOUL-KEY-003');
    console.log('✅ Test keys created: SOUL-KEY-001, 002, 003');
}

// ============================================================
// MIDDLEWARE
// ============================================================
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// ============================================================
// AUTH
// ============================================================
function auth(req, res, next) {
    const token = req.cookies?.token;
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET || 'secret');
        next();
    } catch {
        res.status(401).json({ error: 'Invalid token' });
    }
}

// ============================================================
// ROUTES
// ============================================================

// Login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    if (!bcrypt.compareSync(password, user.password)) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({ success: true, user: { username: user.username, role: user.role } });
});

// Verify key (for APK)
app.post('/api/keys/verify', (req, res) => {
    const { key } = req.body;
    const keyData = db.prepare("SELECT * FROM license_keys WHERE key_value = ?").get(key);
    if (!keyData) return res.json({ valid: false, reason: 'Invalid key' });
    if (keyData.status !== 'active') return res.json({ valid: false, reason: 'Key inactive' });
    if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
        return res.json({ valid: false, reason: 'Key expired' });
    }
    res.json({ valid: true, key: keyData.key_value });
});

// Get keys (for admin panel)
app.get('/api/keys', auth, (req, res) => {
    const keys = db.prepare("SELECT * FROM license_keys").all();
    res.json(keys);
});

// Slot status
app.get('/api/slot/status', (req, res) => {
    res.json({ status: 'available' });
});

// Cooldown status
app.get('/api/cooldown/status', (req, res) => {
    res.json({ status: 'ready', cooldown_remaining: 0 });
});

// ============================================================
// HTML PAGES
// ============================================================

// Login page
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>SOUL DD Login</title>
            <style>
                body { background: #0a0a0f; color: #fff; font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
                .box { background: #14141e; padding: 40px; border-radius: 12px; border: 1px solid #ff4444; width: 320px; }
                h1 { color: #ff4444; text-align: center; }
                input { width: 100%; padding: 10px; margin: 10px 0; background: #1a1a2e; border: 1px solid #333; color: #fff; border-radius: 6px; box-sizing: border-box; }
                button { width: 100%; padding: 12px; background: #ff4444; color: #fff; border: none; border-radius: 6px; font-size: 16px; cursor: pointer; }
                .error { color: #ff4444; text-align: center; margin-top: 10px; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="box">
                <h1>SOUL DD</h1>
                <p style="text-align:center;color:#888;">Devil Control Panel</p>
                <form id="loginForm">
                    <input type="text" id="username" placeholder="Username" value="admin">
                    <input type="password" id="password" placeholder="Password" value="admin123">
                    <button type="submit">Sign In</button>
                </form>
                <div id="message" class="error"></div>
                <div class="footer">@soulcracks owner</div>
            </div>
            <script>
                document.getElementById('loginForm').addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const username = document.getElementById('username').value;
                    const password = document.getElementById('password').value;
                    const msg = document.getElementById('message');
                    msg.textContent = '⏳ Logging in...';
                    try {
                        const res = await fetch('/api/login', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ username, password })
                        });
                        const data = await res.json();
                        if (res.ok && data.success) {
                            msg.textContent = '✅ Success!';
                            msg.style.color = '#44ff44';
                            setTimeout(() => window.location.href = '/dashboard', 1000);
                        } else {
                            msg.textContent = '❌ ' + (data.error || 'Login failed');
                            msg.style.color = '#ff4444';
                        }
                    } catch (err) {
                        msg.textContent = '❌ Network error';
                        msg.style.color = '#ff4444';
                    }
                });
            </script>
        </body>
        </html>
    `);
});

// Dashboard
app.get('/dashboard', auth, (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Dashboard</title>
            <style>
                body { background: #0a0a0f; color: #fff; font-family: Arial; padding: 20px; }
                .nav { display: flex; gap: 20px; padding: 10px 0; border-bottom: 1px solid #333; }
                .nav a { color: #ff4444; text-decoration: none; font-weight: bold; }
                .welcome { font-size: 24px; font-weight: bold; color: #ff4444; margin: 20px 0; }
                .keys { background: #14141e; padding: 20px; border-radius: 12px; border: 1px solid #333; }
                .key { padding: 10px; margin: 5px 0; background: #1a1a2e; border-radius: 6px; font-family: monospace; }
            </style>
        </head>
        <body>
            <div class="nav">
                <a href="/dashboard">Dashboard</a>
                <a href="/dashboard?show=keys">Keys</a>
                <a href="/" onclick="document.cookie='token=;max-age=0;path=/';return true;">Logout</a>
            </div>
            <div class="welcome">👋 Welcome, ${req.user.username}!</div>
            <div class="keys">
                <h2 style="color:#ff4444;">🔑 Available Keys</h2>
                <div id="keysList">Loading...</div>
            </div>
            <p style="color:#666;font-size:12px;margin-top:20px;">Use these keys in the APK: SOUL-KEY-001, 002, 003</p>
            <script>
                fetch('/api/keys')
                    .then(r => r.json())
                    .then(keys => {
                        document.getElementById('keysList').innerHTML = keys.map(k => 
                            '<div class="key">' + k.key_value + ' - ' + k.status + '</div>'
                        ).join('');
                    })
                    .catch(() => {
                        document.getElementById('keysList').innerHTML = 'SOUL-KEY-001<br>SOUL-KEY-002<br>SOUL-KEY-003';
                    });
            </script>
        </body>
        </html>
    `);
});

// ============================================================
// START
// ============================================================
app.listen(PORT, () => {
    console.log(`🚀 Panel running on port ${PORT}`);
    console.log(`👤 Admin: admin / admin123`);
    console.log(`🔑 Keys: SOUL-KEY-001, 002, 003`);
});