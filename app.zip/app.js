require('dotenv').config();

// Validate required env at startup
const REQUIRED_ENV_VARS = ['JWT_SECRET','E2E_KEY_V1','HMAC_SECRET','PROVIDER_KEY','ADMIN_RELEASE_KEY'];
for (const v of REQUIRED_ENV_VARS) {
  if (!process.env[v] || process.env[v].trim() === '') {
    console.error(`FATAL: missing env ${v}`); process.exit(1);
  }
}
if (process.env.JWT_SECRET.length < 32) { console.error('FATAL: JWT_SECRET too short'); process.exit(1); }

const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const winston = require('winston');
require('winston-daily-rotate-file');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');

// ============================================================
// DATABASE SETUP
// ============================================================
const dbPath = path.join(__dirname, 'panel.db');
const db = new Database(dbPath);

// Create users table
db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Create license_keys table
db.exec(`CREATE TABLE IF NOT EXISTS license_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key_value TEXT UNIQUE NOT NULL,
    duration INTEGER DEFAULT 30,
    device_limit INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
)`);

// Auto-create admin
const adminCheck = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
if (!adminCheck) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const stmt = db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    stmt.run('admin', hashedPassword, 'admin');
    console.log('✅ Admin user created!');
    console.log('📝 Username: admin');
    console.log('🔑 Password: admin123');
}

// Auto-create test keys
const keyCheck = db.prepare("SELECT * FROM license_keys LIMIT 1").get();
if (!keyCheck) {
    const keys = [
        ['SOUL-KEY-2026-001', 30],
        ['SOUL-KEY-2026-002', 60],
        ['SOUL-KEY-2026-003', 90]
    ];
    const stmt = db.prepare("INSERT INTO license_keys (key_value, duration, device_limit, status, expires_at) VALUES (?, ?, 1, 'active', datetime('now', '+' || ? || ' days'))");
    for (const [key, duration] of keys) {
        stmt.run(key, duration, duration);
    }
    console.log('✅ Test keys created!');
    console.log('📝 Keys: SOUL-KEY-2026-001, SOUL-KEY-2026-002, SOUL-KEY-2026-003');
}

// ============================================================
// LOGGING
// ============================================================
const LOG_DIR = path.join(__dirname, 'logs');
try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) {}

const accessTransport = new winston.transports.DailyRotateFile({ dirname: LOG_DIR, filename: 'access-%DATE%.log', datePattern: 'YYYY-MM-DD', maxSize: '10m', maxFiles: '14d' });
const securityTransport = new winston.transports.DailyRotateFile({ dirname: LOG_DIR, filename: 'security-%DATE%.log', datePattern: 'YYYY-MM-DD', maxSize: '10m', maxFiles: '30d' });
const accessLogger = winston.createLogger({ transports: [accessTransport] });
const securityLogger = winston.createLogger({ transports: [securityTransport, new winston.transports.Console()] });
global.securityLogger = securityLogger;

// ============================================================
// EXPRESS APP
// ============================================================
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

// Security
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "script-src": ["'self'", "'unsafe-inline'", "'unsafe-hashes'"],
      "style-src": ["'self'", "'unsafe-inline'", "https:"],
      "img-src": ["'self'", "data:", "https:"],
      "connect-src": ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

// CORS
app.use(cors({
  origin: true,
  credentials: true,
}));

// Body parsers
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

// Logging
morgan.token('real-ip', (req) => req.get('cf-connecting-ip') || req.get('x-forwarded-for') || req.ip);
app.use(morgan(':real-ip - :remote-user [:date[clf]] ":method :url" :status :res[content-length] ":referrer" ":user-agent"', {
  stream: { write: (m) => accessLogger.info(m.trim()) }
}));

// Static files
app.use('/static', express.static(path.join(__dirname, 'public')));

// Health check
app.get('/health', (req, res) => res.json({ ok: true, timestamp: new Date().toISOString() }));

// Rate limiting
const globalLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: (req) => req.cookies?.token ? 6000 : 600,
  message: { error: 'Too many requests' },
});
app.use(globalLimiter);

function cfKill(res) { try { res.socket?.destroy(); } catch {} }

// ============================================================
// PAGE AUTH MIDDLEWARE
// ============================================================
function pageAuth(req, res, next) {
    const token = req.cookies?.token;
    if (!token) return res.redirect('/login');
    try {
        jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (err) {
        return res.redirect('/login');
    }
}

// ============================================================
// API ROUTES
// ============================================================

// Login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    try {
        const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
        if (!user) return res.status(401).json({ error: 'Invalid credentials' });
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
        res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 });
        return res.json({ success: true, user: { id: user.id, username: user.username, role: user.role } });
    } catch (error) {
        return res.status(500).json({ error: 'Internal error' });
    }
});

// Key verification (for APK)
app.post('/api/keys/verify', (req, res) => {
    const { key, device_id } = req.body;
    console.log('🔑 Key verification attempt:', { key, device_id });
    
    try {
        const keyData = db.prepare("SELECT * FROM license_keys WHERE key_value = ?").get(key);
        
        if (!keyData) {
            return res.json({ valid: false, reason: 'invalid_key' });
        }
        
        if (keyData.status !== 'active') {
            return res.json({ valid: false, reason: 'key_inactive' });
        }
        
        if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
            return res.json({ valid: false, reason: 'expired' });
        }
        
        // Generate HMAC response
        const crypto = require('crypto');
        const hmac = crypto.createHmac('sha256', process.env.HMAC_SECRET);
        hmac.update(key + ':' + keyData.expires_at);
        const signature = hmac.digest('hex');
        
        return res.json({
            valid: true,
            key: keyData.key_value,
            expires_at: keyData.expires_at,
            duration: keyData.duration,
            signature: signature
        });
    } catch (error) {
        return res.json({ valid: false, reason: 'error', message: error.message });
    }
});

// Slot status
app.get('/api/slot/status', (req, res) => {
    res.json({ status: 'available', message: 'Slot is ready' });
});

// Cooldown status
app.get('/api/cooldown/status', (req, res) => {
    res.json({ status: 'ready', cooldown_remaining: 0 });
});

// ============================================================
// ADMIN PAGES
// ============================================================
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'views', 'login.html')));
app.get('/dashboard', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'dashboard.html')));
app.get('/keys', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'keys.html')));
app.get('/users', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'users.html')));

// ============================================================
// START SERVER
// ============================================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`SOUL DD PANEL v4.2.0 — port ${PORT}`);
  console.log('👤 Admin: admin / admin123');
  console.log('🔑 Test keys: SOUL-KEY-2026-001, 002, 003');
  console.log('🔗 Login: /login');
});

module.exports = app;