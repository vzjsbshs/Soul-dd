require('dotenv').config();

// Validate required env at startup
const REQUIRED_ENV_VARS = ['JWT_SECRET','E2E_KEY_V1','HMAC_SECRET','PROVIDER_KEY','ADMIN_RELEASE_KEY'];
for (const v of REQUIRED_ENV_VARS) {
  if (!process.env[v] || process.env[v].trim() === '') {
    console.error(`FATAL: missing env ${v}`); process.exit(1);
  }
}
if (process.env.JWT_SECRET.length < 32) { console.error('FATAL: JWT_SECRET too short'); process.exit(1); }

const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const winston = require('winston');
require('winston-daily-rotate-file');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');

// ============================================================
// DATABASE SETUP & ADMIN AUTO-CREATION
// ============================================================
const dbPath = path.join(__dirname, 'panel.db');
const db = new Database(dbPath);

// Create users table
db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Check if admin exists, create if not
const adminCheck = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
if (!adminCheck) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const stmt = db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    stmt.run('admin', hashedPassword, 'admin');
    console.log('✅ Admin user created successfully!');
    console.log('📝 Username: admin');
    console.log('🔑 Password: admin123');
} else {
    console.log('✅ Admin user already exists');
}

// ============================================================
// IMPORT ROUTES
// ============================================================
const { pageAuth } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const usersRoutes = require('./routes/users');
const promosRoutes = require('./routes/promos');
const dashboardRoutes = require('./routes/dashboard');
const slotRoutes = require('./routes/slot');
const cooldownRoutes = require('./routes/cooldown');
const adminRoutes = require('./routes/admin');
const keysRoutesV4 = require('./routes/keys-v4');
const apkRoutes = require('./routes/apk');
const configRoutes = require('./routes/config');
const analyticsRoutes = require('./routes/analytics');
const notificationsRoutes = require('./routes/notifications');
const xRoutes = require('./routes/x');
const soulRoutes = require('./routes/soul');
const fireRoutes = require('./routes/fire');
const devicesRoutes = require('./routes/devices');

// ============================================================
// LOGGING
// ============================================================
const LOG_DIR = path.join(__dirname, 'logs');
try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) {}

const accessTransport = new winston.transports.DailyRotateFile({ dirname: LOG_DIR, filename: 'access-%DATE%.log', datePattern: 'YYYY-MM-DD', maxSize: '10m', maxFiles: '14d' });
const securityTransport = new winston.transports.DailyRotateFile({ dirname: LOG_DIR, filename: 'security-%DATE%.log', datePattern: 'YYYY-MM-DD', maxSize: '10m', maxFiles: '30d' });
const accessLogger = winston.createLogger({ transports: [accessTransport] });
const securityLogger = winston.createLogger({ transports: [securityTransport, new winston.transports.Console()] });
global.securityLogger = securityLogger;

// ============================================================
// EXPRESS APP
// ============================================================
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

// Security
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "script-src": ["'self'", "'unsafe-inline'", "'unsafe-hashes'", "https://static.cloudflareinsights.com", "https://cdn.jsdelivr.net"],
      "style-src": ["'self'", "'unsafe-inline'", "https:", "https://cdn.jsdelivr.net"],
      "img-src": ["'self'", "data:", "https:"],
      "font-src": ["'self'", "https:", "data:"],
      "connect-src": ["'self'"],
      "script-src-attr": ["'unsafe-inline'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

// CORS
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);
    if (origin === ALLOWED_ORIGIN || ALLOWED_ORIGIN === '*') return cb(null, true);
    return cb(new Error('CORS not allowed'), false);
  },
  credentials: true,
}));

// Body parsers
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

// Logging
morgan.token('redacted-url', (req) => {
  let url = req.url;
  url = url.replace(/([?&])(key|device_id|sig|p|t|token|assigned_to)=([^&]+)/gi, '$1$2=REDACTED');
  return url;
});
morgan.token('real-ip', (req) => req.get('cf-connecting-ip') || req.get('x-forwarded-for') || req.ip);
app.use(morgan(':real-ip - :remote-user [:date[clf]] ":method :redacted-url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent"', {
  stream: { write: (m) => accessLogger.info(m.trim()) }
}));

// Static files
app.use('/static', express.static(path.join(__dirname, 'public')));

// Health check
app.get('/health', (req, res) => res.json({ ok: true }));

// Rate limiting
const globalLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: (req) => req.cookies?.token ? 6000 : 600,
  message: { error: 'Too many requests' },
  standardHeaders: false,
  legacyHeaders: false,
});
app.use(globalLimiter);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 5,
  message: { error: 'Too many authentication attempts' },
  skipSuccessfulRequests: true,
  standardHeaders: false,
});

function cfKill(res) { try { res.socket?.destroy(); } catch {} }

// ============================================================
// DOWNLOADS GATING
// ============================================================
app.use('/downloads', (req, res, next) => {
  try {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('CDN-Cache-Control', 'no-store');
    if (!req.path.toLowerCase().endsWith('.apk')) {
      return express.static(path.join(__dirname, 'public', 'downloads'))(req, res, next);
    }
    const token = (req.query.t || '').toString();
    if (!token || !token.includes(':')) return cfKill(res);
    const [apkId, keyVal] = token.split(':');
    if (!apkId || !keyVal) return cfKill(res);
    const key = db.prepare('SELECT * FROM license_keys WHERE key_value = ?').get(keyVal);
    if (!key || key.status === 'revoked') return cfKill(res);
    if (key.duration_type !== 'lifetime' && key.expires_at && new Date(key.expires_at) <= new Date()) return cfKill(res);
    return express.static(path.join(__dirname, 'public', 'downloads'))(req, res, next);
  } catch (e) { return cfKill(res); }
});

// ============================================================
// MOBILE UA BLOCKING
// ============================================================
const MOBILE_ALLOWED = new Set(['/api/x','/api/keys/verify','/api/slot/status','/api/cooldown/status','/api/fire','/api/soul']);
app.use((req, res, next) => {
  const ua = (req.get('user-agent') || '').toLowerCase();
  if (req.path.startsWith('/api/') && ua.includes('okhttp')) {
    if (![...MOBILE_ALLOWED].some(p => req.path === p || req.path.startsWith(p + '/'))) {
      return cfKill(res);
    }
  }
  next();
});

// ============================================================
// ROUTES
// ============================================================
app.use('/api/x', xRoutes);
app.use('/api/soul', soulRoutes);
app.use('/api/fire', fireRoutes);
app.use('/api/keys', keysRoutesV4);
app.use('/api/slot', slotRoutes);
app.use('/api/cooldown', cooldownRoutes);

app.use('/api/analytics', analyticsRoutes);
app.use('/admin/devices', devicesRoutes);
app.use('/admin/apk', apkRoutes);
app.use('/admin/config', configRoutes);
app.use('/admin/notifications', notificationsRoutes);

// Admin pages
app.get('/', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'dashboard.html')));
app.get('/keys', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'keys.html')));
app.get('/users', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'users.html')));
app.get('/promos', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'promos.html')));
app.get('/admin-stats', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'admin-stats.html')));
app.get('/change-password', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'change-password.html')));
app.get('/dashboard', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'dashboard.html')));
app.get('/apk', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'apk-management.html')));
app.get('/devices', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'devices.html')));
app.get('/analytics', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'analytics.html')));
app.get('/control', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'control.html')));
app.get('/notifications', pageAuth, (req, res) => res.sendFile(path.join(__dirname, 'views', 'notifications.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'views', 'login.html')));
app.get('/register', (req, res) => res.status(410).json({ error: 'registration_disabled' }));

app.use('/auth', authLimiter, authRoutes);
app.use('/api/users', usersRoutes);
app.use('/users', usersRoutes);
app.use('/api/promos', promosRoutes);
app.use('/promos', promosRoutes);
app.use('/dashboard', dashboardRoutes);
app.use('/admin', adminRoutes);

// ============================================================
// CONTACT / TELEGRAM
// ============================================================
app.get('/api/contact/telegram', (req, res) => {
  res.json({ success: true, telegram: '@soulcracks_owner', message: 'Contact us on Telegram for support or inquiries' });
});

// ============================================================
// 404 & ERROR HANDLING
// ============================================================
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return cfKill(res);
  res.status(404).json({ error: 'not_found' });
});

app.use((err, req, res, next) => {
  securityLogger.error('Server error:', err);
  res.status(500).json({ error: 'internal_error' });
});

// ============================================================
// WAL CHECKPOINT
// ============================================================
setInterval(() => {
  try { db.prepare('PRAGMA wal_checkpoint(TRUNCATE)').run(); }
  catch (e) { securityLogger.warn('wal_checkpoint failed: ' + e.message); }
}, 6 * 60 * 60 * 1000);

// ============================================================
// START SERVER
// ============================================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`SOUL DD PANEL v4.2.0 — port ${PORT}`);
  console.log('Mobile endpoints: /api/x, /api/keys/verify, /api/slot/status, /api/cooldown/status');
  console.log('👤 Admin: admin / admin123');
});

module.exports = app;