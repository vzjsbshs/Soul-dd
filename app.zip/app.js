require('dotenv').config();

const path = require('path');
const fs = require('fs');
const express = require('express');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');

// ============================================================
// DATABASE SETUP
// ============================================================
const dbPath = path.join(__dirname, 'panel.db');
const db = new Database(dbPath);

// Create users table
db.exec(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Create license_keys table
db.exec(`CREATE TABLE IF NOT EXISTS license_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key_value TEXT UNIQUE NOT NULL,
    duration INTEGER DEFAULT 30,
    device_limit INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
)`);

// Auto-create admin
const adminCheck = db.prepare("SELECT * FROM users WHERE username = ?").get('admin');
if (!adminCheck) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    const stmt = db.prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    stmt.run('admin', hashedPassword, 'admin');
    console.log('✅ Admin created: admin / admin123');
}

// Auto-create test keys
const keyCheck = db.prepare("SELECT * FROM license_keys LIMIT 1").get();
if (!keyCheck) {
    const keys = [
        ['SOUL-KEY-2026-001', 30],
        ['SOUL-KEY-2026-002', 60],
        ['SOUL-KEY-2026-003', 90]
    ];
    const stmt = db.prepare("INSERT INTO license_keys (key_value, duration, device_limit, status, expires_at) VALUES (?, ?, 1, 'active', datetime('now', '+' || ? || ' days'))");
    for (const [key, duration] of keys) {
        stmt.run(key, duration, duration);
    }
    console.log('✅ Test keys created');
    console.log('📝 Keys: SOUL-KEY-2026-001, 002, 003');
}

// ============================================================
// EXPRESS APP
// ============================================================
const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ============================================================
// AUTH MIDDLEWARE
// ============================================================
function requireAuth(req, res, next) {
    const token = req.cookies?.token;
    if (!token) return res.redirect('/login');
    try {
        jwt.verify(token, process.env.JWT_SECRET || 'secret');
        next();
    } catch {
        return res.redirect('/login');
    }
}

// ============================================================
// ROOT ROUTE
// ============================================================
app.get('/', (req, res) => {
    const token = req.cookies?.token;
    if (token) {
        try {
            jwt.verify(token, process.env.JWT_SECRET || 'secret');
            return res.redirect('/dashboard');
        } catch {}
    }
    res.redirect('/login');
});

// ============================================================
// LOGIN ROUTE
// ============================================================
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    try {
        const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
        if (!user) return res.status(401).json({ error: 'Invalid credentials' });
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role },
            process.env.JWT_SECRET || 'secret',
            { expiresIn: '7d' }
        );
        res.cookie('token', token, { httpOnly: true, sameSite: 'lax', maxAge: 7 * 24 * 60 * 60 * 1000 });
        res.json({ success: true, user: { username: user.username, role: user.role } });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

// ============================================================
// ⬇️⬇️⬇️ APK ROUTES (THESE WERE MISSING!) ⬇️⬇️⬇️
// ============================================================

// KEY VERIFICATION ROUTE (for APK)
app.get('/api/keys/verify', (req, res) => {
    const { key } = req.query;
    console.log('🔑 Key verification:', key);
    
    if (!key) {
        return res.json({ valid: false, reason: 'missing_key' });
    }
    
    try {
        const keyData = db.prepare("SELECT * FROM license_keys WHERE key_value = ?").get(key);
        
        if (!keyData) {
            return res.json({ valid: false, reason: 'invalid_key' });
        }
        
        if (keyData.status !== 'active') {
            return res.json({ valid: false, reason: 'key_inactive' });
        }
        
        if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
            return res.json({ valid: false, reason: 'expired' });
        }
        
        // Generate HMAC signature
        const crypto = require('crypto');
        const hmac = crypto.createHmac('sha256', process.env.HMAC_SECRET || 'f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1');
        hmac.update(key + ':' + keyData.expires_at);
        const signature = hmac.digest('hex');
        
        res.json({
            valid: true,
            key: keyData.key_value,
            expires_at: keyData.expires_at,
            duration: keyData.duration,
            signature: signature
        });
    } catch (error) {
        res.json({ valid: false, reason: 'error', message: error.message });
    }
});

// SLOT STATUS ROUTE
app.get('/api/slot/status', (req, res) => {
    res.json({ status: 'available', message: 'Slot is ready' });
});

// COOLDOWN STATUS ROUTE
app.get('/api/cooldown/status', (req, res) => {
    res.json({ status: 'ready', cooldown_remaining: 0 });
});

// POST version for key verification (if app uses POST)
app.post('/api/keys/verify', (req, res) => {
    const { key } = req.body;
    console.log('🔑 Key verification (POST):', key);
    
    if (!key) {
        return res.json({ valid: false, reason: 'missing_key' });
    }
    
    try {
        const keyData = db.prepare("SELECT * FROM license_keys WHERE key_value = ?").get(key);
        
        if (!keyData) {
            return res.json({ valid: false, reason: 'invalid_key' });
        }
        
        if (keyData.status !== 'active') {
            return res.json({ valid: false, reason: 'key_inactive' });
        }
        
        if (keyData.expires_at && new Date(keyData.expires_at) < new Date()) {
            return res.json({ valid: false, reason: 'expired' });
        }
        
        const crypto = require('crypto');
        const hmac = crypto.createHmac('sha256', process.env.HMAC_SECRET || 'f1c30c1ead99fe7fe7ebc6a99a7a5d5fc9cd07d864a92416ce8c014725f304a1');
        hmac.update(key + ':' + keyData.expires_at);
        const signature = hmac.digest('hex');
        
        res.json({
            valid: true,
            key: keyData.key_value,
            expires_at: keyData.expires_at,
            duration: keyData.duration,
            signature: signature
        });
    } catch (error) {
        res.json({ valid: false, reason: 'error', message: error.message });
    }
});

// ============================================================
// ⬆️⬆️⬆️ END OF APK ROUTES ⬆️⬆️⬆️
// ============================================================

// ============================================================
// PAGES
// ============================================================
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/dashboard', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

app.get('/keys', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'keys.html'));
});

app.get('/users', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'users.html'));
});

// ============================================================
// START SERVER
// ============================================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`✅ Panel running on port ${PORT}`);
    console.log(`👤 Admin: admin / admin123`);
    console.log(`🔑 Keys: SOUL-KEY-2026-001, 002, 003`);
    console.log(`🔗 URL: https://soul-panel.onrender.com`);
    console.log(`📡 API: /api/keys/verify`);
});