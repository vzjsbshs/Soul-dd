const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');
const { audit } = require('../db/database-v4');

// Get all keys visible to current user
function getVisibleKeys(user) {
  if (user.role === 'owner') {
    return db.prepare(`
      SELECT 
        k.*,
        u1.username as assigned_username,
        u2.username as creator_username,
        (SELECT COUNT(*) FROM device_bindings WHERE key_id = k.id) as device_count
      FROM license_keys k
      LEFT JOIN users u1 ON k.assigned_to = u1.id
      LEFT JOIN users u2 ON k.created_by = u2.id
      ORDER BY k.created_at DESC
    `).all();
  } else {
    return db.prepare(`
      SELECT 
        k.*,
        u1.username as assigned_username,
        (SELECT COUNT(*) FROM device_bindings WHERE key_id = k.id) as device_count
      FROM license_keys k
      LEFT JOIN users u1 ON k.assigned_to = u1.id
      WHERE k.created_by = ? OR k.assigned_to = ?
      ORDER BY k.created_at DESC
    `).all(user.id, user.id);
  }
}

// Calculate expiration date based on duration type and value
function calculateExpiration(durationType, durationValue) {
  const now = Date.now();
  let ms;
  
  switch (durationType) {
    case 'hours':
      ms = durationValue * 60 * 60 * 1000;
      break;
    case 'days':
      ms = durationValue * 24 * 60 * 60 * 1000;
      break;
    case 'weeks':
      ms = durationValue * 7 * 24 * 60 * 60 * 1000;
      break;
    case 'months':
      ms = durationValue * 30 * 24 * 60 * 60 * 1000;
      break;
    case 'years':
      ms = durationValue * 365 * 24 * 60 * 60 * 1000;
      break;
    case 'lifetime':
      // Set to 100 years from now for "lifetime"
      ms = 100 * 365 * 24 * 60 * 60 * 1000;
      break;
    default:
      ms = 30 * 24 * 60 * 60 * 1000; // Default 30 days
  }
  
  return new Date(now + ms).toISOString();
}

// GET /keys - List all keys
router.get('/', authRequired, (req, res) => {
  const keys = getVisibleKeys(req.user);
  res.json({ keys });
});

// POST /keys - Create new key(s) with v4 features
router.post('/', authRequired, (req, res) => {
  const {
    assigned_to,
    duration_type = 'days',
    duration_value = 30,
    max_devices = 1,
    tier = 'standard',
    quantity = 1,
    features,
    metadata
  } = req.body || {};
  
  // Validate inputs
  const userId = assigned_to ? parseInt(assigned_to, 10) : null;
  const dType = ['hours', 'days', 'weeks', 'months', 'years', 'lifetime'].includes(duration_type) ? duration_type : 'days';
  const dValue = duration_type === 'lifetime' ? 0 : Math.max(1, Math.min(parseInt(duration_value, 10) || 30, 999));
  const maxDev = Math.max(1, Math.min(parseInt(max_devices, 10) || 1, 999));
  const keyTier = ['standard', 'premium', 'vip'].includes(tier) ? tier : 'standard';
  const count = Math.min(parseInt(quantity, 10) || 1, 100);
  
  // Check if assigned user exists
  if (userId) {
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!target) return res.status(404).json({ error: 'User not found' });
    
    // Permission check
    if (req.user.role !== 'owner' && target.approved_by !== req.user.id) {
      return res.status(403).json({ error: 'Cannot assign key to this user' });
    }
  }
  
  // Calculate expiration
  const expiresAt = calculateExpiration(dType, dValue);
  
  // Create keys
  const createdKeys = [];
  const stmt = db.prepare(`
    INSERT INTO license_keys (
      key_value, 
      assigned_to, 
      created_by, 
      expires_at,
      duration_type,
      duration_value,
      max_devices,
      tier,
      features,
      metadata,
      status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
  `);
  
  for (let i = 0; i < count; i++) {
    const keyValue = uuidv4().replace(/-/g, '').toUpperCase();
    
    stmt.run(
      keyValue,
      userId,
      req.user.id,
      expiresAt,
      dType,
      dValue,
      maxDev,
      keyTier,
      features ? JSON.stringify(features) : null,
      metadata ? JSON.stringify(metadata) : null
    );
    
    createdKeys.push({ key_value: keyValue });
  }
  
  // Audit log
  audit(req.user.id, 'keys_created', userId, {
    count,
    duration_type: dType,
    duration_value: dValue,
    max_devices: maxDev,
    tier: keyTier
  });
  
  res.json({
    ok: true,
    created: count,
    keys: createdKeys,
    message: `Successfully created ${count} license key(s)`
  });
});

// DELETE /keys/:id - Delete a key
router.delete('/:id', authRequired, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(id);
  
  if (!key) return res.status(404).json({ error: 'Key not found' });
  
  // Permission check
  if (req.user.role !== 'owner' && key.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Permission denied' });
  }
  
  // Delete key
  db.prepare('DELETE FROM license_keys WHERE id = ?').run(id);
  
  // Also delete associated device bindings
  db.prepare('DELETE FROM device_bindings WHERE key_id = ?').run(id);
  
  audit(req.user.id, 'key_deleted', id);
  
  res.json({ ok: true, message: 'Key deleted successfully' });
});

// POST /keys/:id/reset - Reset device binding for a key
router.post('/:id/reset', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(id);
  
  if (!key) return res.status(404).json({ error: 'Key not found' });
  
  if (req.user.role === 'admin' && key.created_by !== req.user.id) {
    return res.status(403).json({ error: 'Permission denied' });
  }
  
  // Remove all device bindings
  db.prepare('DELETE FROM device_bindings WHERE key_id = ?').run(id);
  
  // Reset device_id in license_keys (legacy field)
  db.prepare("UPDATE license_keys SET device_id = NULL, status = 'active' WHERE id = ?").run(id);
  
  audit(req.user.id, 'key_reset', id);
  
  res.json({ ok: true, message: 'Key reset successfully, all devices unbound' });
});

// GET /keys/export.csv - Export keys to CSV
router.get('/export.csv', authRequired, requireRole('owner'), (req, res) => {
  const rows = getVisibleKeys(req.user);
  
  const header = 'id,key_value,assigned_username,creator_username,status,tier,expires_at,duration_type,duration_value,max_devices,device_count,created_at\n';
  const body = rows.map(r => [
    r.id,
    r.key_value,
    r.assigned_username || '',
    r.creator_username || '',
    r.status,
    r.tier || 'standard',
    r.expires_at,
    r.duration_type || 'days',
    r.duration_value || 30,
    r.max_devices || 1,
    r.device_count || 0,
    r.created_at
  ].join(',')).join('\n');
  
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="soul-dd-keys.csv"');
  res.send(header + body);
});

module.exports = router;
