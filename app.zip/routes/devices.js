const express = require('express');
const { db, audit, logEvent } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// PROMPTV3 R1: Public mobile handlers DELETED.
// Mobile clients MUST use /api/x → dispatch (devices/list, bind, self-unbind).

// Admin: list all devices
router.get('/all', authRequired, requireRole('owner', 'admin'), (req, res) => {
  try {
    const devices = db.prepare(`
      SELECT db.*, lk.key_value
      FROM device_bindings db
      LEFT JOIN license_keys lk ON db.key_id = lk.id
      ORDER BY db.last_active DESC
    `).all();
    res.json(devices);
  } catch (error) {
    res.status(500).json({ error: 'server_error' });
  }
});

// Admin-only DELETE
router.delete('/:id', authRequired, requireRole('owner', 'admin'), (req, res) => {
  try {
    const deviceBindingId = parseInt(req.params.id);
    if (!deviceBindingId) return res.status(400).json({ error: 'missing_params' });

    const binding = db.prepare('SELECT * FROM device_bindings WHERE id = ?').get(deviceBindingId);
    if (!binding) return res.status(404).json({ error: 'device_not_found' });

    const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(binding.key_id);

    db.prepare('DELETE FROM device_bindings WHERE id = ?').run(deviceBindingId);
    logEvent('device_unbound', key ? key.assigned_to : null, binding.key_id, binding.device_id);
    audit(req.user.id, 'device_unbound_admin', binding.key_id, { device_id: binding.device_id });

    res.json({ success: true, message: 'device_removed', device_id: binding.device_id });
  } catch (error) {
    res.status(500).json({ error: 'server_error' });
  }
});

// Admin-only PUT (rename)
router.put('/:id', authRequired, requireRole('owner', 'admin'), (req, res) => {
  try {
    const deviceBindingId = parseInt(req.params.id);
    const { device_name } = req.body;

    if (!deviceBindingId) return res.status(400).json({ error: 'missing_params' });

    const binding = db.prepare('SELECT * FROM device_bindings WHERE id = ?').get(deviceBindingId);
    if (!binding) return res.status(404).json({ error: 'device_not_found' });

    if (device_name !== undefined) {
      db.prepare('UPDATE device_bindings SET device_name = ? WHERE id = ?').run(device_name, deviceBindingId);
    }

    const updated = db.prepare('SELECT * FROM device_bindings WHERE id = ?').get(deviceBindingId);
    res.json({ success: true, message: 'device_updated', device: { id: updated.id, device_id: updated.device_id, device_name: updated.device_name, device_model: updated.device_model } });
  } catch (error) {
    res.status(500).json({ error: 'server_error' });
  }
});

module.exports = router;
