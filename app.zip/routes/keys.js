const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db, audit } = require('../db/database');
const { authRequired, requireRole } = require('../middleware/auth');
const { recordVerifyFail } = require('../middleware/security');

const router = express.Router();

// Public: Android app calls this with key + device_id
router.get('/verify', (req, res) => {
  const key = req.query.key;
  const deviceId = req.query.device_id;
  if (!key || !deviceId) {
    recordVerifyFail(req.ip);
    return res.json({ valid: false, reason: 'missing_params' });
  }

  const k = db.prepare('SELECT * FROM license_keys WHERE key_value = ?').get(key);
  if (!k) {
    recordVerifyFail(req.ip);
    return res.json({ valid: false, reason: 'invalid_key' });
  }

  if (k.status === 'revoked') {
    recordVerifyFail(req.ip);
    return res.json({ valid: false, reason: 'revoked' });
  }

  const now = new Date();
  const exp = new Date(k.expires_at);
  if (exp <= now) {
    db.prepare("UPDATE license_keys SET status = 'expired' WHERE id = ?").run(k.id);
    return res.json({ valid: false, reason: 'expired' });
  }

  if (!k.device_id) {
    db.prepare("UPDATE license_keys SET device_id = ?, status = 'device_bound', last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(deviceId, k.id);
    audit(k.assigned_to, 'key_bound', k.id, { device_id: deviceId });
    return res.json({ valid: true, expires_at: k.expires_at, bound: true });
  }

  if (k.device_id !== deviceId) {
    recordVerifyFail(req.ip);
    return res.json({ valid: false, reason: 'wrong_device' });
  }

  db.prepare("UPDATE license_keys SET last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(k.id);
  return res.json({ valid: true, expires_at: k.expires_at, bound: true });
});

function getVisibleKeys(user) {
  if (user.role === 'owner') {
    return db.prepare(`
      SELECT k.*, u.username as assigned_username, c.username as creator_username
      FROM license_keys k
      LEFT JOIN users u ON u.id = k.assigned_to
      LEFT JOIN users c ON c.id = k.created_by
      ORDER BY k.created_at DESC
    `).all();
  }
  return db.prepare(`
    SELECT k.*, u.username as assigned_username, c.username as creator_username
    FROM license_keys k
    LEFT JOIN users u ON u.id = k.assigned_to
    LEFT JOIN users c ON c.id = k.created_by
    WHERE k.created_by = ?
    ORDER BY k.created_at DESC
  `).all(user.id);
}

router.get('/', authRequired, (req, res) => {
  res.json({ keys: getVisibleKeys(req.user) });
});

router.post('/', authRequired, (req, res) => {
  const { assigned_to_user_id, expires_days, count } = req.body || {};
  const userId = assigned_to_user_id ? parseInt(assigned_to_user_id, 10) : null;
  const days = parseInt(expires_days, 10) || 30;
  const n = Math.min(parseInt(count, 10) || 1, 100);

  if (userId) {
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!target) return res.status(404).json({ error: 'user_not_found' });
    if (req.user.role !== 'owner' && target.approved_by !== req.user.id) {
      return res.status(403).json({ error: 'not_your_user' });
    }
  }

  const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
  const created = [];
  const stmt = db.prepare(`INSERT INTO license_keys (key_value, assigned_to, created_by, expires_at) VALUES (?, ?, ?, ?)`);
  for (let i = 0; i < n; i++) {
    const k = uuidv4().replace(/-/g, '').toUpperCase();
    stmt.run(k, userId, req.user.id, expiresAt);
    created.push(k);
  }
  audit(req.user.id, 'keys_created', userId, { count: n, days });
  res.json({ ok: true, created });
});

router.delete('/:id', authRequired, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const k = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(id);
  if (!k) return res.status(404).json({ error: 'not_found' });
  if (req.user.role !== 'owner' && k.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare('DELETE FROM license_keys WHERE id = ?').run(id);
  audit(req.user.id, 'key_deleted', id);
  res.json({ ok: true });
});

router.post('/:id/reset', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const k = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(id);
  if (!k) return res.status(404).json({ error: 'not_found' });
  if (req.user.role === 'admin' && k.created_by !== req.user.id) return res.status(403).json({ error: 'not_your_key' });
  db.prepare("UPDATE license_keys SET device_id = NULL, status = 'active' WHERE id = ?").run(id);
  audit(req.user.id, 'key_reset', id);
  res.json({ ok: true });
});

router.get('/export.csv', authRequired, requireRole('owner'), (req, res) => {
  const rows = getVisibleKeys(req.user);
  const header = 'id,key_value,assigned_username,creator_username,device_id,expires_at,status,created_at,last_verified\n';
  const body = rows.map(r => [r.id, r.key_value, r.assigned_username || '', r.creator_username || '',
    r.device_id || '', r.expires_at, r.status, r.created_at, r.last_verified || ''].join(',')).join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="keys.csv"');
  res.send(header + body);
});

module.exports = router;
