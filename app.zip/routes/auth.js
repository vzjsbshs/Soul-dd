const express = require('express');
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit');
const { db, audit } = require('../db/database');
const { signToken, authRequired } = require('../middleware/auth');

const router = express.Router();

const loginLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'too_many_attempts' }
});

/**
 * Public registration is DISABLED.
 * The Android app no longer uses username/password.
 * Admin accounts are seeded via init-db.js or created by an existing owner.
 */
router.post('/register', (_req, res) => res.status(410).json({ error: 'registration_disabled' }));

/**
 * Admin login (web panel only). Mobile app does NOT use this endpoint.
 */
router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'missing_fields' });
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user) return res.status(401).json({ error: 'invalid_credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid_credentials' });
  if (user.status === 'banned') return res.status(403).json({ error: 'banned' });
  if (user.status !== 'approved') return res.status(403).json({ error: 'pending_approval' });

  const token = signToken(user);
  res.cookie('token', token, { httpOnly: true, sameSite: 'lax', secure: req.secure || req.get('x-forwarded-proto') === 'https', maxAge: 7 * 24 * 60 * 60 * 1000 });
  audit(user.id, 'login');
  res.json({
    ok: true,
    token,
    user: { id: user.id, username: user.username, role: user.role, must_change_password: !!user.must_change_password }
  });
});

router.post('/logout', (_req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

router.get('/me', authRequired, (req, res) => {
  res.json({ user: { id: req.user.id, username: req.user.username, role: req.user.role, must_change_password: !!req.user.must_change_password } });
});

router.post('/change-password', authRequired, async (req, res) => {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password || new_password.length < 6) return res.status(400).json({ error: 'invalid_input' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const ok = await bcrypt.compare(current_password, u.password_hash);
  if (!ok) return res.status(401).json({ error: 'wrong_current_password' });
  const hash = await bcrypt.hash(new_password, 12);
  db.prepare('UPDATE users SET password_hash = ?, must_change_password = 0, token_version = token_version + 1 WHERE id = ?').run(hash, u.id);
  audit(u.id, 'password_changed');
  res.clearCookie('token');
  res.json({ ok: true });
});

module.exports = router;
