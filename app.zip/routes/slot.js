/**
 * /api/slot — Global slot status (PROMPTV4 V2 FIX: HMAC-gated or uniform responses)
 * PROMPTV3 R6: POST /release requires authRequired + requireRole('owner') + ADMIN_RELEASE_KEY.
 *
 * Uses global_state key/value table (same module fire.js uses).
 */
const express = require('express');
const { db } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');
const { hmacVerify, blockMiddleware } = require('../middleware/security');

const router = express.Router();

// Ensure global_state table exists (fire.js uses the same schema)
try {
  db.prepare(`CREATE TABLE IF NOT EXISTS global_state (key TEXT PRIMARY KEY, value TEXT)`).run();
} catch (_) {}

function getGlobalState(key) {
  try {
    const row = db.prepare("SELECT value FROM global_state WHERE key = ?").get(key);
    return row ? row.value : null;
  } catch (_) { return null; }
}
function setGlobalState(key, value) {
  try {
    db.prepare(`INSERT INTO global_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`).run(key, value);
  } catch (_) {}
}

// PROMPTV4 V2 FIX: HMAC-gate /status to prevent enumeration
router.get('/status', blockMiddleware, hmacVerify, (_req, res) => {
  const lockedUntil = getGlobalState('slot_locked_until');
  const busy = !!(lockedUntil && new Date(lockedUntil) > new Date());
  const remaining = busy ? Math.max(0, Math.ceil((new Date(lockedUntil) - new Date()) / 1000)) : 0;
  
  // PROMPTV4 V2: Mask fired_by (only show last-4 chars or null)
  const firedBy = getGlobalState('slot_fired_by');
  const maskedFiredBy = (busy && firedBy) ? ('****' + firedBy.slice(-4)) : null;
  
  return res.json({
    busy,
    remaining_seconds: remaining,
    fired_by: maskedFiredBy
  });
});

router.post('/release', authRequired, requireRole('owner'), (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  const expectedKey = process.env.ADMIN_RELEASE_KEY;
  if (!expectedKey || adminKey !== expectedKey) {
    if (global.securityLogger) global.securityLogger.warn(`[slot] release attempted without admin-key by user=${req.user && req.user.username} ip=${req.get('cf-connecting-ip') || req.ip}`);
    return res.status(403).json({ ok: false, reason: 'forbidden' });
  }

  setGlobalState('slot_locked_until', null);
  setGlobalState('slot_fired_by', null);

  if (global.securityLogger) global.securityLogger.warn(`[slot] EMERGENCY RELEASE by ${req.user && req.user.username} ip=${req.get('cf-connecting-ip') || req.ip}`);
  try { const { audit } = require('../db/database-v4'); audit(req.user.id, 'slot_released', null, { ip: req.get('cf-connecting-ip') || req.ip }); } catch (_) {}
  return res.json({ ok: true, message: 'slot released' });
});

module.exports = router;
