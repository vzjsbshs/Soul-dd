const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db, audit } = require('../db/database');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/', authRequired, requireRole('owner', 'admin'), (req, res) => {
  let rows;
  if (req.user.role === 'owner') {
    rows = db.prepare(`SELECT p.*, u.username as creator_username
                       FROM promo_codes p LEFT JOIN users u ON u.id = p.created_by
                       ORDER BY p.created_at DESC`).all();
  } else {
    rows = db.prepare(`SELECT p.*, u.username as creator_username
                       FROM promo_codes p LEFT JOIN users u ON u.id = p.created_by
                       WHERE p.created_by = ? ORDER BY p.created_at DESC`).all(req.user.id);
  }
  res.json({ promos: rows });
});

router.post('/', authRequired, requireRole('owner', 'admin'), (req, res) => {
  let { code, max_uses } = req.body || {};
  if (!code) code = uuidv4().split('-')[0].toUpperCase();
  code = String(code).toUpperCase();
  max_uses = parseInt(max_uses, 10) || 1;
  const exists = db.prepare('SELECT id FROM promo_codes WHERE LOWER(code) = LOWER(?)').get(code);
  if (exists) return res.status(409).json({ error: 'code_exists' });
  const info = db.prepare('INSERT INTO promo_codes (code, created_by, max_uses) VALUES (?, ?, ?)').run(code, req.user.id, max_uses);
  audit(req.user.id, 'promo_created', info.lastInsertRowid, { code, max_uses });
  res.json({ ok: true, code, id: info.lastInsertRowid });
});

router.delete('/:id', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const p = db.prepare('SELECT * FROM promo_codes WHERE id = ?').get(id);
  if (!p) return res.status(404).json({ error: 'not_found' });
  if (req.user.role !== 'owner' && p.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare('DELETE FROM promo_codes WHERE id = ?').run(id);
  audit(req.user.id, 'promo_deleted', id);
  res.json({ ok: true });
});

router.post('/:id/toggle', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const p = db.prepare('SELECT * FROM promo_codes WHERE id = ?').get(id);
  if (!p) return res.status(404).json({ error: 'not_found' });
  if (req.user.role !== 'owner' && p.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare('UPDATE promo_codes SET is_active = ? WHERE id = ?').run(p.is_active ? 0 : 1, id);
  res.json({ ok: true });
});

module.exports = router;
