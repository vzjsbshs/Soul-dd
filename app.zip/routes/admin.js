/**
 * /api/admin/stats — Owner-only API call stats (per-key + global).
 * Protected by JWT auth + role=owner. Reuses the existing admin token
 * (cookie 'token' or Authorization: Bearer ...).
 */
const express = require('express');
const { db } = require('../db/database');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// All routes here require an authenticated owner
router.use(authRequired, requireRole('owner'));

router.get('/stats', (_req, res) => {
  // Global summary
  const totalKeysRegistered = db.prepare('SELECT COUNT(*) as c FROM license_keys').get().c;
  const activeKeys = db.prepare(
    "SELECT COUNT(*) as c FROM license_keys WHERE status IN ('active','device_bound') AND expires_at > datetime('now')"
  ).get().c;
  const totalApiCalls = db.prepare('SELECT COUNT(*) as c FROM api_calls').get().c;
  const callsToday = db.prepare(
    "SELECT COUNT(*) as c FROM api_calls WHERE created_at >= datetime('now','start of day')"
  ).get().c;
  const callsWeek = db.prepare(
    "SELECT COUNT(*) as c FROM api_calls WHERE created_at >= datetime('now','-7 days')"
  ).get().c;
  const callsMonth = db.prepare(
    "SELECT COUNT(*) as c FROM api_calls WHERE created_at >= datetime('now','-30 days')"
  ).get().c;

  // Per-key breakdown
  const keys = db.prepare(`
    SELECT k.id, k.key_value, k.status, k.expires_at, k.cooldown_seconds,
           u.username AS assigned_username
    FROM license_keys k
    LEFT JOIN users u ON u.id = k.assigned_to
    ORDER BY k.id DESC
  `).all();

  const perKey = keys.map(k => {
    const total   = db.prepare('SELECT COUNT(*) as c FROM api_calls WHERE key_id = ?').get(k.id).c;
    const today   = db.prepare("SELECT COUNT(*) as c FROM api_calls WHERE key_id = ? AND created_at >= datetime('now','start of day')").get(k.id).c;
    const week    = db.prepare("SELECT COUNT(*) as c FROM api_calls WHERE key_id = ? AND created_at >= datetime('now','-7 days')").get(k.id).c;
    const month   = db.prepare("SELECT COUNT(*) as c FROM api_calls WHERE key_id = ? AND created_at >= datetime('now','-30 days')").get(k.id).c;
    const last    = db.prepare('SELECT created_at, ip, port, duration FROM api_calls WHERE key_id = ? ORDER BY id DESC LIMIT 1').get(k.id);
    const uniqIps = db.prepare('SELECT COUNT(DISTINCT ip) as c FROM api_calls WHERE key_id = ?').get(k.id).c;
    const avgDur  = db.prepare("SELECT AVG(CAST(duration AS REAL)) as a FROM api_calls WHERE key_id = ? AND duration IS NOT NULL").get(k.id).a;

    const isExpired = new Date(k.expires_at) <= new Date();
    return {
      key_id: k.id,
      key_value: k.key_value,
      assigned_to: k.assigned_username || null,
      status: isExpired ? 'expired' : k.status,
      expires_at: k.expires_at,
      cooldown_seconds: k.cooldown_seconds || 180,
      total_calls: total,
      calls_today: today,
      calls_week: week,
      calls_month: month,
      last_call_at: last ? last.created_at : null,
      last_ip: last ? last.ip : null,
      last_port: last ? last.port : null,
      last_duration: last ? last.duration : null,
      unique_ips: uniqIps,
      avg_duration: avgDur ? Math.round(avgDur * 100) / 100 : null,
    };
  });

  res.json({
    summary: {
      total_keys_registered: totalKeysRegistered,
      active_keys: activeKeys,
      total_api_calls: totalApiCalls,
      calls_today: callsToday,
      calls_week: callsWeek,
      calls_month: callsMonth,
    },
    per_key: perKey,
    generated_at: new Date().toISOString(),
  });
});

module.exports = router;
