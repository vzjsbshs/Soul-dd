const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { db, audit, canBindDevice, bindDevice, updateDeviceActivity, logEvent, isMaintenanceMode, isKillSwitchActive, isFeatureEnabled } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');
const { recordVerifyFail, hmacVerify, blockMiddleware } = require('../middleware/security');

const router = express.Router();

// PROMPTV4 V1 FIX: HMAC-gate the legacy /verify endpoint + add audit logging
// Block until HMAC header is present. Uniform response for invalid keys.
router.get('/verify', blockMiddleware, hmacVerify, (req, res) => {
  const keyValue = req.query.key;
  const deviceId = req.query.device_id;
  const device_model = req.query.device_model;
  const device_brand = req.query.device_brand;
  const android_version = req.query.android_version;
  const app_version = req.query.app_version;

  // PROMPTV4 V1: Validate device_id format (UUID without dashes)
  if (!keyValue || !deviceId) {
    recordVerifyFail(req);
    return res.json({ valid: false, reason: 'missing_params' });
  }
  
  // Device ID must be UUID-like (alphanumeric, 32 chars)
  if (!/^[a-f0-9]{32}$/i.test(deviceId)) {
    recordVerifyFail(req);
    return res.json({ valid: false, reason: 'invalid_params' });
  }

  if (isMaintenanceMode()) return res.json({ valid: false, reason: 'maintenance_mode', message: 'System is under maintenance.' });
  if (isKillSwitchActive()) return res.json({ valid: false, reason: 'app_disabled', message: 'App is temporarily disabled.' });

  const k = db.prepare('SELECT * FROM license_keys WHERE key_value = ?').get(keyValue);
  
  // PROMPTV4 V1 + N20: Audit every verify attempt (even failures)
  const auditDetails = { 
    ip: req.get('cf-connecting-ip') || req.ip, 
    key_last4: keyValue ? keyValue.slice(-4) : null,
    device_id: deviceId,
    result: 'unknown'
  };
  
  if (!k) { 
    auditDetails.result = 'invalid_key';
    try { audit(null, 'key_verify_failed', null, auditDetails); } catch (_) {}
    recordVerifyFail(req); 
    return res.json({ valid: false, reason: 'invalid' }); // PROMPTV4 V1: uniform response
  }
  
  if (k.status === 'revoked') { 
    auditDetails.result = 'revoked';
    try { audit(null, 'key_verify_failed', k.id, auditDetails); } catch (_) {}
    recordVerifyFail(req); 
    return res.json({ valid: false, reason: 'invalid' }); // uniform
  }

  if (k.duration_type !== 'lifetime') {
    const now = new Date();
    if (new Date(k.expires_at) <= now) {
      db.prepare("UPDATE license_keys SET status = 'expired' WHERE id = ?").run(k.id);
      auditDetails.result = 'expired';
      try { audit(null, 'key_verify_failed', k.id, auditDetails); } catch (_) {}
      return res.json({ valid: false, reason: 'expired', expires_at: k.expires_at });
    }
  }

  const multiDeviceEnabled = isFeatureEnabled('multi_device_enabled');
  const deviceCountRow = db.prepare('SELECT COUNT(*) as count FROM device_bindings WHERE key_id = ?').get(k.id);
  const current_devices = deviceCountRow.count;
  const max_devices = k.max_devices;

  if (multiDeviceEnabled && k.max_devices > 1) {
    const existingBinding = db.prepare('SELECT * FROM device_bindings WHERE key_id = ? AND device_id = ?').get(k.id, deviceId);
    if (existingBinding) {
      if (existingBinding.approved === 0) {
        auditDetails.result = 'device_pending';
        try { audit(k.assigned_to, 'key_verified', k.id, auditDetails); } catch (_) {}
        return res.json({ valid: false, reason: 'device_pending_approval', max_devices, current_devices });
      }
      updateDeviceActivity(k.id, deviceId);
      db.prepare("UPDATE license_keys SET last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(k.id);
      auditDetails.result = 'success_existing';
      try { audit(k.assigned_to, 'key_verified', k.id, auditDetails); } catch (_) {}
      logEvent('key_verified', k.assigned_to, k.id, deviceId);
      return res.json({ valid: true, expires_at: k.expires_at, duration_type: k.duration_type, tier: k.tier, device_id: deviceId, device_name: existingBinding.device_name, bound: true, multi_device: true, max_devices, current_devices });
    }
    
    // PROMPTV4 N12: Wrap bindDevice in transaction to prevent race condition
    const txn = db.transaction(() => {
      // Re-check count inside transaction
      const countCheck = db.prepare('SELECT COUNT(*) as count FROM device_bindings WHERE key_id = ?').get(k.id);
      if (countCheck.count >= k.max_devices) {
        return { ok: false, reason: 'device_limit_reached' };
      }
      const bindOk = bindDevice(k.id, deviceId, { device_model, device_brand, android_version, app_version, ip_address: req.get('cf-connecting-ip') || req.ip, device_type: 'mobile' });
      if (!bindOk) return { ok: false, reason: 'bind_failed' };
      return { ok: true };
    });
    
    const result = txn();
    if (!result.ok) {
      auditDetails.result = result.reason;
      try { audit(k.assigned_to, 'key_verify_failed', k.id, auditDetails); } catch (_) {}
      return res.json({ valid: false, reason: result.reason, max_devices, current_devices });
    }
    
    logEvent('device_bound', k.assigned_to, k.id, deviceId, { device_model, device_brand });
    db.prepare("UPDATE license_keys SET last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(k.id);
    auditDetails.result = 'success_new_bind';
    try { audit(k.assigned_to, 'key_verified', k.id, auditDetails); } catch (_) {}
    return res.json({ valid: true, expires_at: k.expires_at, duration_type: k.duration_type, tier: k.tier, device_id: deviceId, bound: true, newly_bound: true, multi_device: true, max_devices, current_devices: current_devices + 1 });
  }

  // Single-device mode
  if (!k.device_id) {
    db.prepare("UPDATE license_keys SET device_id = ?, status = 'device_bound', last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(deviceId, k.id);
    bindDevice(k.id, deviceId, { device_model, device_brand, android_version, app_version, ip_address: req.get('cf-connecting-ip') || req.ip, device_type: 'mobile' });
    auditDetails.result = 'success_first_bind';
    try { audit(k.assigned_to, 'key_verified', k.id, auditDetails); } catch (_) {}
    logEvent('key_verified', k.assigned_to, k.id, deviceId);
    return res.json({ valid: true, expires_at: k.expires_at, duration_type: k.duration_type, tier: k.tier, bound: true, newly_bound: true, max_devices: 1, current_devices: 1 });
  }
  if (k.device_id !== deviceId) { 
    auditDetails.result = 'wrong_device';
    try { audit(k.assigned_to, 'key_verify_failed', k.id, auditDetails); } catch (_) {}
    recordVerifyFail(req); 
    return res.json({ valid: false, reason: 'invalid', max_devices: 1, current_devices: 1 }); // uniform
  }
  db.prepare("UPDATE license_keys SET last_verified = CURRENT_TIMESTAMP WHERE id = ?").run(k.id);
  auditDetails.result = 'success';
  try { audit(k.assigned_to, 'key_verified', k.id, auditDetails); } catch (_) {}
  logEvent('key_verified', k.assigned_to, k.id, deviceId);
  return res.json({ valid: true, expires_at: k.expires_at, duration_type: k.duration_type, tier: k.tier, bound: true, max_devices: 1, current_devices: 1 });
});

// PROMPTV4 V7 FIX: Mask key_value completely (no last-4 to prevent fingerprinting)
function maskKey(kv) { 
  if (!kv) return kv; 
  return '****'; // No last-4 chars
}

function getVisibleKeys(user) {
  let query, params;
  if (user.role === 'owner') {
    query = `SELECT k.*, u.username as assigned_username, c.username as creator_username, (SELECT COUNT(*) FROM device_bindings WHERE key_id = k.id) as device_count FROM license_keys k LEFT JOIN users u ON u.id = k.assigned_to LEFT JOIN users c ON c.id = k.created_by ORDER BY k.created_at DESC`;
    params = [];
  } else {
    query = `SELECT k.id, k.key_value, k.assigned_to, k.created_by, k.expires_at, k.status, k.created_at, k.last_verified, k.last_fire_at, k.cooldown_seconds, k.duration_type, k.duration_value, k.max_devices, k.tier, u.username as assigned_username, (SELECT COUNT(*) FROM device_bindings WHERE key_id = k.id) as device_count FROM license_keys k LEFT JOIN users u ON u.id = k.assigned_to WHERE k.created_by = ? ORDER BY k.created_at DESC`;
    params = [user.id];
  }
  const rows = db.prepare(query).all(...params);
  if (user.role === 'owner') return rows;
  // Mask key_value for non-owner
  return rows.map(r => ({ ...r, key_value: maskKey(r.key_value) }));
}

router.get('/', authRequired, (req, res) => {
  const rows = getVisibleKeys(req.user);
  try { audit(req.user.id, 'keys_listed', null, { ip: req.get('cf-connecting-ip') || req.ip, count: rows.length }); } catch (_) {}
  res.json({ keys: rows });
});

// PROMPTV4 V4 FIX: Harden /reveal endpoint
// Add Cache-Control, rate limit, one-time token, richer audit
const revealLimiter = new Map(); // user_id -> [timestamps]
const REVEAL_WINDOW_MS = 60 * 60 * 1000; // 1 hour
const REVEAL_MAX_PER_HOUR = 20;

router.get('/:id/reveal', authRequired, requireRole('owner'), (req, res) => {
  const id = parseInt(req.params.id);
  
  // Rate limit: 20 reveals/hour per owner
  const now = Date.now();
  const userId = req.user.id;
  const attempts = (revealLimiter.get(userId) || []).filter(ts => now - ts < REVEAL_WINDOW_MS);
  if (attempts.length >= REVEAL_MAX_PER_HOUR) {
    return res.status(429).json({ error: 'rate_limit_exceeded', message: 'Too many reveal requests. Try again later.' });
  }
  attempts.push(now);
  revealLimiter.set(userId, attempts);
  
  const k = db.prepare('SELECT id, key_value, created_by FROM license_keys WHERE id = ?').get(id);
  if (!k) return res.status(404).json({ error: 'key_not_found' });
  
  // PROMPTV4 N14: Defense-in-depth - even though requireRole('owner') is present, double-check
  if (req.user.role !== 'owner' && k.created_by !== req.user.id) {
    return res.status(403).json({ error: 'forbidden' });
  }
  
  // PROMPTV4 V4: Rich audit with UA, CF-JA3, device fingerprint
  const auditDetails = {
    ip: req.get('cf-connecting-ip') || req.ip,
    ua: req.get('user-agent'),
    cf_ja3: req.get('cf-ja3'),
    referer: req.get('referer')
  };
  try { audit(req.user.id, 'key_revealed', k.id, auditDetails); } catch (_) {}
  
  // PROMPTV4 V4: Cache-Control headers
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  
  // TODO V4: Implement one-time JWT token (deferred to avoid breaking existing UI)
  // For now, return the key_value directly with strong cache prevention
  res.json({ id: k.id, key_value: k.key_value });
});

// PROMPTV4 V8 FIX: Add Cache-Control to POST /keys response
router.post('/', authRequired, (req, res) => {
  const { assigned_to_user_id, duration_type = 'days', duration_value, max_devices = 1, tier = 'standard', count = 1, expires_days } = req.body || {};
  const userId = assigned_to_user_id ? parseInt(assigned_to_user_id, 10) : null;
  const dType = duration_type;
  let dValue = duration_value ? parseInt(duration_value, 10) : (expires_days ? parseInt(expires_days, 10) : 30);
  const maxDev = Math.min(Math.max(parseInt(max_devices, 10) || 1, 1), 999);
  const n = Math.min(parseInt(count, 10) || 1, 100);

  if (userId) {
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!target) return res.status(404).json({ error: 'user_not_found' });
    if (req.user.role !== 'owner' && target.approved_by !== req.user.id) return res.status(403).json({ error: 'not_your_user' });
  }

  let expiresAt;
  if (dType === 'lifetime') expiresAt = null;
  else {
    const multiplier = { 'hours': 60*60*1000, 'days': 24*60*60*1000, 'weeks': 7*24*60*60*1000, 'months': 30*24*60*60*1000, 'years': 365*24*60*60*1000 };
    expiresAt = new Date(Date.now() + (multiplier[dType] || multiplier['days']) * dValue).toISOString();
  }

  const created = [];
  const stmt = db.prepare(`INSERT INTO license_keys (key_value, assigned_to, created_by, expires_at, duration_type, duration_value, max_devices, tier) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  for (let i = 0; i < n; i++) {
    const keyValue = uuidv4().replace(/-/g, '').toUpperCase();
    stmt.run(keyValue, userId, req.user.id, expiresAt, dType, dValue, maxDev, tier);
    created.push(keyValue);
  }
  audit(req.user.id, 'keys_created', userId, { count: n, duration_type: dType, duration_value: dValue, max_devices: maxDev, tier });
  logEvent('keys_created', req.user.id, null, null, { count: n, tier });
  
  // PROMPTV4 V8: Add Cache-Control to prevent caching of created keys
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  
  res.json({ ok: true, created, details: { duration_type: dType, duration_value: dValue, max_devices: maxDev, tier, expires_at: expiresAt } });
});

router.delete('/:id', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const keyId = parseInt(req.params.id);
  const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(keyId);
  if (!key) return res.status(404).json({ error: 'key_not_found' });
  if (req.user.role !== 'owner' && key.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare('DELETE FROM device_bindings WHERE key_id = ?').run(keyId);
  db.prepare('DELETE FROM license_keys WHERE id = ?').run(keyId);
  
  // PROMPTV4 V5 FIX: Mask key_value in audit (store only last-4)
  audit(req.user.id, 'key_deleted', keyId, { key_last4: key.key_value.slice(-4) });
  res.json({ ok: true, message: 'key_deleted' });
});

router.post('/:id/reset', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const keyId = parseInt(req.params.id);
  const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(keyId);
  if (!key) return res.status(404).json({ error: 'key_not_found' });
  if (req.user.role !== 'owner' && key.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare('DELETE FROM device_bindings WHERE key_id = ?').run(keyId);
  db.prepare(`UPDATE license_keys SET device_id = NULL, status = 'active', last_fire_at = NULL, last_verified = NULL WHERE id = ?`).run(keyId);
  audit(req.user.id, 'key_reset', keyId);
  res.json({ ok: true, message: 'key_reset' });
});

router.post('/:id/revoke', authRequired, requireRole('owner', 'admin'), (req, res) => {
  const keyId = parseInt(req.params.id);
  const key = db.prepare('SELECT * FROM license_keys WHERE id = ?').get(keyId);
  if (!key) return res.status(404).json({ error: 'key_not_found' });
  if (req.user.role !== 'owner' && key.created_by !== req.user.id) return res.status(403).json({ error: 'forbidden' });
  db.prepare("UPDATE license_keys SET status = 'revoked' WHERE id = ?").run(keyId);
  audit(req.user.id, 'key_revoked', keyId);
  res.json({ ok: true, message: 'key_revoked' });
});

module.exports = router;
