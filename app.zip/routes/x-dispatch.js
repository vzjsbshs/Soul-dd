const { db, audit, logEvent, getDeviceBindings, canBindDevice, bindDevice, updateDeviceActivity, isFeatureEnabled, getConfig, getLatestApk, isMaintenanceMode, isKillSwitchActive } = require('../db/database-v4');

async function dispatch(p, key, req) {
  const now = new Date();
  const path = `${p.method} ${p.path}`;

  switch (path) {

    case 'GET /api/keys/verify': {
      if (isMaintenanceMode()) return { valid:false, reason:'maintenance_mode' };
      if (isKillSwitchActive()) return { valid:false, reason:'app_disabled' };
      if (key.duration_type !== 'lifetime' && new Date(key.expires_at) <= now) {
        db.prepare("UPDATE license_keys SET status='expired' WHERE id=?").run(key.id);
        return { valid:false, reason:'expired' };
      }
      const deviceId = p.device_id; 
      if (!deviceId) return { valid:false, reason:'missing_device' };
      const multi = isFeatureEnabled('multi_device_enabled') && key.max_devices > 1;
      const existing = db.prepare('SELECT * FROM device_bindings WHERE key_id=? AND device_id=?').get(key.id, deviceId);
      const count = db.prepare('SELECT COUNT(*) c FROM device_bindings WHERE key_id=?').get(key.id).c;
      if (existing) {
        updateDeviceActivity(key.id, deviceId);
        db.prepare("UPDATE license_keys SET last_verified=CURRENT_TIMESTAMP WHERE id=?").run(key.id);
        return { valid:true, expires_at:key.expires_at, duration_type:key.duration_type, tier:key.tier, max_devices:key.max_devices, current_devices:count, bound:true };
      }
      if (multi && !canBindDevice(key.id)) return { valid:false, reason:'device_limit_reached', max_devices:key.max_devices, current_devices:count };
      if (!multi && key.device_id && key.device_id !== deviceId) return { valid:false, reason:'wrong_device' };
      bindDevice(key.id, deviceId, { device_model:p.params?.device_model, device_brand:p.params?.device_brand, android_version:p.params?.android_version, app_version:p.params?.app_version, ip_address:req.ip, device_type:'mobile' });
      if (!multi) db.prepare("UPDATE license_keys SET device_id=?, status='device_bound', last_verified=CURRENT_TIMESTAMP WHERE id=?").run(deviceId, key.id);
      return { valid:true, expires_at:key.expires_at, duration_type:key.duration_type, tier:key.tier, max_devices:key.max_devices, current_devices:count+1, bound:true, newly_bound:true };
    }

    case 'GET /api/devices':           
      return { devices: getDeviceBindings(key.id), max_devices:key.max_devices };
      
    case 'DELETE /api/devices/self':   {
      const did = p.device_id;
      const b = db.prepare('SELECT * FROM device_bindings WHERE key_id=? AND device_id=?').get(key.id, did);
      if (!b) return { ok:false, reason:'not_found' };
      db.prepare('DELETE FROM device_bindings WHERE id=?').run(b.id);
      logEvent('device_unbound', key.assigned_to, key.id, did);
      return { ok:true };
    }

    case 'GET /api/apk/latest': {
      const apk = getLatestApk(p.params?.channel || 'stable');
      if (!apk) return { ok:false, reason:'none' };
      logEvent('apk_check', key.assigned_to, key.id);
      return { ok:true, apk:{ id:apk.id, version_code:apk.version_code, version_name:apk.version_name, file_hash:apk.file_hash, file_size:apk.file_size, force_update:!!apk.force_update, release_notes:apk.release_notes, download_token:`${apk.id}:${key.key_value}` } };
    }

    case 'GET /api/config':            
      return { config: Object.fromEntries(db.prepare('SELECT config_key,config_value,config_type FROM app_configs WHERE is_active=1').all().map(c=>[c.config_key, c.config_type==='boolean'?(c.config_value==='1'||c.config_value==='true'):c.config_type==='number'?Number(c.config_value):c.config_type==='json'?JSON.parse(c.config_value):c.config_value])), features: Object.fromEntries(db.prepare('SELECT flag_key,flag_value FROM feature_flags').all().map(f=>[f.flag_key, !!f.flag_value])) };

    case 'GET /api/notifications':     
      return { notifications: db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(key.assigned_to || 0) };
      
    case 'PUT /api/notifications/read':{ 
      db.prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?').run(p.params?.id, key.assigned_to || 0); 
      return { ok:true }; 
    }

    case 'GET /api/slot/status':       
      return db.prepare('SELECT * FROM slot_state WHERE id=1').get() || {};
      
    case 'GET /api/cooldown/status':   {
      const last = key.last_fire_at ? new Date(key.last_fire_at).getTime() : 0;
      const cd   = (key.cooldown_seconds || 180);
      const remaining = Math.max(0, Math.floor((last + cd*1000 - Date.now())/1000));
      return { cooldown_remaining_seconds: remaining, cooldown_seconds: cd };
    }

    case 'POST /api/fire': {
      // params (p.params) is forwarded verbatim and must include:
      // ip, port, time, option, payload1, payload2, payload3
      const fwd = p.params || {};
      return require('./fire').__internalFire
        ? require('./fire').__internalFire(key, fwd, req)
        : { ok:false, reason:'not_implemented' };
    }

    case 'GET /api/ping':              
      return { ok:true, t: Date.now() };

    default: 
      return { ok:false, reason:'unknown_path' };
  }
}

module.exports = { dispatch };
