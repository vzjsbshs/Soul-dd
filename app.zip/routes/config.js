/**
 * Configuration & Remote Control Routes — admin-only.
 * PROMPTV3 R4: Public GET /, GET /check-update, GET /maintenance/status DELETED.
 * Mobile clients use /api/x dispatch (GET /api/config) for app config & feature flags.
 */

const express = require('express');
const { db, audit, logEvent, getConfig, setConfig, isMaintenanceMode } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

router.post('/', authRequired, requireRole('owner'), (req, res) => {
  const { config_key, config_value } = req.body;
  if (!config_key || config_value === undefined) return res.status(400).json({ error: 'missing_params' });
  const success = setConfig(config_key, config_value, req.user.id);
  if (!success) return res.status(404).json({ error: 'config_not_found' });
  audit(req.user.id, 'config_updated', null, { config_key, config_value });
  logEvent('config_updated', req.user.id, null, null, { config_key });
  res.json({ success: true, message: 'Configuration updated', config_key, config_value });
});

router.post('/maintenance/enable', authRequired, requireRole('owner'), (req, res) => {
  const { message, duration_minutes } = req.body;
  setConfig('maintenance_mode', true, req.user.id);
  if (message) setConfig('maintenance_message', message, req.user.id);
  if (duration_minutes) {
    const startTime = new Date().toISOString();
    const endTime = new Date(Date.now() + duration_minutes * 60 * 1000).toISOString();
    db.prepare(`INSERT INTO maintenance_windows (start_time, end_time, message, created_by) VALUES (?, ?, ?, ?)`).run(startTime, endTime, message || '', req.user.id);
  }
  audit(req.user.id, 'maintenance_enabled', null, { message, duration_minutes });
  logEvent('maintenance_enabled', req.user.id);
  res.json({ success: true, message: 'Maintenance mode enabled', maintenance_mode: true });
});

router.post('/maintenance/disable', authRequired, requireRole('owner'), (req, res) => {
  setConfig('maintenance_mode', false, req.user.id);
  audit(req.user.id, 'maintenance_disabled');
  logEvent('maintenance_disabled', req.user.id);
  res.json({ success: true, message: 'Maintenance mode disabled', maintenance_mode: false });
});

router.post('/killswitch/enable', authRequired, requireRole('owner'), (req, res) => {
  setConfig('app_kill_switch', true, req.user.id);
  audit(req.user.id, 'killswitch_enabled');
  res.json({ success: true, message: 'Kill switch enabled' });
});

router.post('/killswitch/disable', authRequired, requireRole('owner'), (req, res) => {
  setConfig('app_kill_switch', false, req.user.id);
  audit(req.user.id, 'killswitch_disabled');
  res.json({ success: true, message: 'Kill switch disabled' });
});

module.exports = router;
