const express = require('express');
const { db, audit } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// FIX A13: Add requireRole check
router.get('/', authRequired, requireRole('owner', 'admin', 'normal_approver'), (req, res) => {
  let rows;
  if (req.user.role === 'owner') {
    rows = db.prepare(`SELECT u.id, u.username, u.role, u.status, u.promo_used, u.created_at,
                              a.username as approver_username
                       FROM users u LEFT JOIN users a ON a.id = u.approved_by
                       ORDER BY u.created_at DESC`).all();
  } else {
    rows = db.prepare(`SELECT u.id, u.username, u.role, u.status, u.promo_used, u.created_at,
                              a.username as approver_username
                       FROM users u LEFT JOIN users a ON a.id = u.approved_by
                       WHERE u.approved_by = ?
                       ORDER BY u.created_at DESC`).all(req.user.id);
  }
  res.json({ users: rows });
});

router.post('/:id/approve', authRequired, requireRole('owner', 'admin', 'normal_approver'), (req, res) => {
  const userId = parseInt(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!u) return res.status(404).json({ error: 'user_not_found' });
  if (u.status !== 'pending') return res.status(400).json({ error: 'not_pending' });
  
  db.prepare("UPDATE users SET status = 'approved', approved_by = ? WHERE id = ?").run(req.user.id, userId);
  audit(req.user.id, 'user_approved', userId);
  res.json({ ok: true });
});

router.post('/:id/reject', authRequired, requireRole('owner', 'admin', 'normal_approver'), (req, res) => {
  const userId = parseInt(req.params.id);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!u) return res.status(404).json({ error: 'user_not_found' });
  
  db.prepare("UPDATE users SET status = 'rejected' WHERE id = ?").run(userId);
  audit(req.user.id, 'user_rejected', userId);
  res.json({ ok: true });
});

router.delete('/:id', authRequired, requireRole('owner'), (req, res) => {
  const userId = parseInt(req.params.id);
  if (userId === req.user.id) return res.status(400).json({ error: 'cannot_delete_self' });
  
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!u) return res.status(404).json({ error: 'user_not_found' });
  
  db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  audit(req.user.id, 'user_deleted', userId);
  res.json({ ok: true });
});

module.exports = router;
