/**
 * Notifications & Communication Routes — admin-only.
 * PROMPTV3 R2: Public mobile handlers DELETED.
 * Mobile clients use /api/x dispatch (GET /api/notifications, PUT /api/notifications/read).
 */

const express = require('express');
const { db, audit, createNotification } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

// Admin: list all notifications
router.get('/all', authRequired, requireRole('owner'), (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 200').all();
    res.json({ notifications: rows });
  } catch (e) {
    res.status(500).json({ error: 'server_error' });
  }
});

router.post('/broadcast', authRequired, requireRole('owner'), (req, res) => {
  const { title, message, type = 'info' } = req.body;
  if (!title || !message) return res.status(400).json({ error: 'missing_params' });
  const users = db.prepare('SELECT id FROM users').all();
  const stmt = db.prepare(`INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)`);
  let count = 0;
  users.forEach(u => { stmt.run(u.id, title, message, type); count++; });
  audit(req.user.id, 'notification_broadcast', null, { title, count });
  res.json({ success: true, message: 'Notification broadcast successfully', recipients: count });
});

router.post('/send', authRequired, requireRole('owner'), (req, res) => {
  const { user_id, title, message, type = 'info' } = req.body;
  if (!user_id || !title || !message) return res.status(400).json({ error: 'missing_params' });
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(user_id);
  if (!user) return res.status(404).json({ error: 'user_not_found' });
  createNotification(user_id, title, message, type);
  audit(req.user.id, 'notification_sent', user_id, { title });
  res.json({ success: true, message: 'Notification sent successfully' });
});

router.delete('/:id', authRequired, requireRole('owner'), (req, res) => {
  const notificationId = parseInt(req.params.id);
  const notification = db.prepare('SELECT * FROM notifications WHERE id = ?').get(notificationId);
  if (!notification) return res.status(404).json({ error: 'notification_not_found' });
  db.prepare('DELETE FROM notifications WHERE id = ?').run(notificationId);
  audit(req.user.id, 'notification_deleted', notificationId);
  res.json({ success: true, message: 'Notification deleted' });
});

module.exports = router;
