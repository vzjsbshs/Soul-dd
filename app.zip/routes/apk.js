/**
 * APK Version Management Routes
 * PROMPTV3 R3: Public /latest and /download/:id handlers DELETED.
 * Mobile clients call /api/x → dispatch GET /api/apk/latest which returns a download_token,
 * then fetch the binary via /downloads/<file>.apk?t=<id>:<key>.
 *
 * S2: PUT /version/:id now uses a strict column whitelist (no template-literal SQL from req.body).
 * S6: APK upload validates magic bytes (PK\x03\x04).
 * S7: /build has timeout + scrubbed stderr + bounded stdout.
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { exec } = require('child_process');
const { db, audit, logEvent } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '..', 'public', 'downloads');
    fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `soul-dd-${Date.now()}.apk`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/vnd.android.package-archive' || file.originalname.endsWith('.apk')) {
      cb(null, true);
    } else {
      cb(new Error('Only APK files are allowed'));
    }
  }
});

// S6: verify ZIP magic bytes (APK is a ZIP)
function isValidApkMagic(filePath) {
  try {
    const fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(4);
    fs.readSync(fd, buf, 0, 4, 0);
    fs.closeSync(fd);
    return buf[0] === 0x50 && buf[1] === 0x4B && buf[2] === 0x03 && buf[3] === 0x04;
  } catch (_) { return false; }
}

router.post('/upload', authRequired, requireRole('owner'), upload.single('apk'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'no_file_uploaded' });

    if (!isValidApkMagic(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(400).json({ error: 'invalid_apk_magic' });
    }

    const { version_code, version_name, channel = 'stable', release_notes = '', force_update = false, rollout_percentage = 100 } = req.body;

    if (!version_code || !version_name) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(400).json({ error: 'missing_version_info' });
    }

    const fileBuffer = fs.readFileSync(req.file.path);
    const hash = crypto.createHash('sha256').update(fileBuffer).digest('hex');

    const result = db.prepare(`
      INSERT INTO apk_versions (version_code, version_name, file_path, file_size, file_hash,
        channel, release_notes, force_update, rollout_percentage, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(parseInt(version_code), version_name, req.file.filename, req.file.size, hash, channel,
        release_notes, force_update ? 1 : 0, parseInt(rollout_percentage), req.user.id);

    audit(req.user.id, 'apk_uploaded', result.lastInsertRowid, { version_name, channel });
    logEvent('apk_uploaded', req.user.id, null, null, { version_code, version_name });

    res.json({ success: true, message: 'APK uploaded successfully',
      apk: { id: result.lastInsertRowid, version_code, version_name, channel, file_size: req.file.size, hash } });
  } catch (err) {
    if (req.file) { try { fs.unlinkSync(req.file.path); } catch (_) {} }
    res.status(500).json({ error: 'upload_failed' });
  }
});

router.post('/build', authRequired, requireRole('owner'), (req, res) => {
  const { version_code, version_name, channel = 'stable', release_notes = '' } = req.body;
  if (!version_code || !version_name) return res.status(400).json({ error: 'missing_version_info' });

  // S7: 10-minute timeout, bounded buffers, scrubbed errors
  const child = exec('/home/ubuntu/scripts/build-apk.sh',
    { timeout: 10 * 60 * 1000, maxBuffer: 256 * 1024 },
    (error, stdout, stderr) => {
      if (error) {
        if (global.securityLogger) global.securityLogger.error(`apk_build_failed: ${error.code || ''} ${(stderr||'').slice(0,500)}`);
        return res.status(500).json({ error: 'build_failed' });
      }
      try {
        const buildInfo = JSON.parse(stdout.trim().split('\n').pop());
        const fileBuffer = fs.readFileSync(buildInfo.file);
        const hash = crypto.createHash('sha256').update(fileBuffer).digest('hex');
        const result = db.prepare(`
          INSERT INTO apk_versions (version_code, version_name, file_path, file_size, file_hash, channel, release_notes, created_by)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(parseInt(version_code), version_name, path.basename(buildInfo.file), buildInfo.size, hash, channel, release_notes, req.user.id);
        audit(req.user.id, 'apk_built', result.lastInsertRowid, { version_name, channel });
        logEvent('apk_built', req.user.id, null, null, { version_code, version_name });
        res.json({ success: true, apk: { id: result.lastInsertRowid, version_code, version_name, channel, file_size: buildInfo.size, hash } });
      } catch (parseErr) {
        res.status(500).json({ error: 'build_result_parse_failed' });
      }
    });
});

router.get('/versions', authRequired, (req, res) => {
  const versions = db.prepare(`
    SELECT v.*, u.username as created_by_username
    FROM apk_versions v LEFT JOIN users u ON u.id = v.created_by
    ORDER BY v.version_code DESC
  `).all();
  res.json({ versions });
});

// S2: column whitelist for PUT /version/:id (no SQL injection via req.body keys)
const ALLOWED_APK_COLUMNS = new Set(['is_active', 'force_update', 'rollout_percentage', 'release_notes']);
router.put('/version/:id', authRequired, requireRole('owner'), (req, res) => {
  const apkId = parseInt(req.params.id);
  const apk = db.prepare('SELECT * FROM apk_versions WHERE id = ?').get(apkId);
  if (!apk) return res.status(404).json({ error: 'apk_not_found' });

  const updates = [];
  const values = [];

  for (const col of Object.keys(req.body || {})) {
    if (!ALLOWED_APK_COLUMNS.has(col)) continue;
    let v = req.body[col];
    if (col === 'is_active' || col === 'force_update') v = v ? 1 : 0;
    else if (col === 'rollout_percentage') v = parseInt(v);
    updates.push(`${col} = ?`);
    values.push(v);
  }

  if (updates.length === 0) return res.status(400).json({ error: 'no_updates_provided' });

  values.push(apkId);
  db.prepare(`UPDATE apk_versions SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  audit(req.user.id, 'apk_updated', apkId, { columns: updates.length });
  res.json({ success: true, message: 'APK version updated' });
});

router.delete('/version/:id', authRequired, requireRole('owner'), (req, res) => {
  const apkId = parseInt(req.params.id);
  const apk = db.prepare('SELECT * FROM apk_versions WHERE id = ?').get(apkId);
  if (!apk) return res.status(404).json({ error: 'apk_not_found' });

  const filePath = path.join(__dirname, '..', 'public', 'downloads', apk.file_path);
  try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
  db.prepare('DELETE FROM apk_versions WHERE id = ?').run(apkId);
  audit(req.user.id, 'apk_deleted', apkId, { version_name: apk.version_name });
  res.json({ success: true, message: 'APK version deleted' });
});

module.exports = router;
