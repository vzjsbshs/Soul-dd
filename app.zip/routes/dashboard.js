/**
 * PROMPTV4 V6 FIX: Strip audit_log.details from dashboard to prevent key_value leaks
 */
const express = require('express');
const { db } = require('../db/database');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

router.get('/stats', authRequired, (req, res) => {
  const isOwner = req.user.role === 'owner';
  const userScope = isOwner ? '' : 'WHERE k.created_by = ?';
  const params = isOwner ? [] : [req.user.id];

  const totalKeys = db.prepare(`SELECT COUNT(*) as c FROM license_keys k ${userScope}`).get(...params).c;
  const activeKeys = db.prepare(`SELECT COUNT(*) as c FROM license_keys k ${userScope ? userScope + " AND" : "WHERE"} status IN ('active','device_bound') AND expires_at > datetime('now')`).get(...params).c;
  const expiringSoon = db.prepare(`SELECT COUNT(*) as c FROM license_keys k ${userScope ? userScope + " AND" : "WHERE"} expires_at BETWEEN datetime('now') AND datetime('now', '+7 days') AND status != 'revoked'`).get(...params).c;

  let totalUsers, pendingUsers;
  if (isOwner) {
    totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
    pendingUsers = db.prepare("SELECT COUNT(*) as c FROM users WHERE status = 'pending'").get().c;
  } else {
    totalUsers = db.prepare('SELECT COUNT(*) as c FROM users WHERE approved_by = ?').get(req.user.id).c;
    pendingUsers = db.prepare("SELECT COUNT(*) as c FROM users WHERE approved_by = ? AND status = 'pending'").get(req.user.id).c;
  }

  // PROMPTV4 V6 FIX: Exclude 'details' column from audit_log to prevent leaking key_values
  const recent = db.prepare(`
    SELECT a.id, a.action, a.created_at, a.target_id, u.username as actor_username
    FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id
    ${isOwner ? '' : 'WHERE a.actor_id = ?'}
    ORDER BY a.id DESC LIMIT 20
  `).all(...(isOwner ? [] : [req.user.id]));

  res.json({
    role: req.user.role,
    username: req.user.username,
    stats: { totalKeys, activeKeys, expiringSoon, totalUsers, pendingUsers },
    recent_activity: recent
  });
});

module.exports = router;
