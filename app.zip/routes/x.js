const express = require('express');
const crypto = require('crypto');
const { decrypt, encrypt, verifySig, replayOk, TS_WINDOW } = require('../crypto/e2e');
const { db } = require('../db/database-v4');
const router = express.Router();
const { dispatch } = require('./x-dispatch');

const HMAC_SECRET = process.env.HMAC_SECRET || '';
const HMAC_REQUIRED = String(process.env.HMAC_REQUIRED || 'false').toLowerCase() === 'true';

// Helper: log + send a clear JSON error (NEVER destroy the socket — that causes nginx 502).
function reject(res, code, reason, extra = {}) {
  try {
    console.error(`[x-gateway][REJECT] code=${code} reason=${reason} ${JSON.stringify(extra)}`);
  } catch (_) {}
  if (global.securityLogger) {
    try { global.securityLogger.warn(`[x-gateway] reject ${reason} ${JSON.stringify(extra)}`); } catch (_) {}
  }
  // Use 200 with a JSON body so OkHttp / clients don't classify it as a transport failure.
  // The body itself signals { ok:false, reason }.
  return res.status(200).json({ ok: false, reason });
}

router.post('/', express.json({ limit: '32kb' }), async (req, res) => {
  let envForLog = null;
  try {
    const env = req.body;
    envForLog = env;
    if (!env || env.v !== 1 || !env.iv || !env.ct || !env.tag || !env.ts || !env.kid) {
      return reject(res, 400, 'bad_envelope', { has: env ? Object.keys(env) : null });
    }

    // Verify envelope signature
    const sig = req.get('X-Request-Sig') || '';
    if (!verifySig(env, sig)) {
      return reject(res, 401, 'bad_envelope_sig', { sigLen: sig.length, kid: env.kid });
    }

    const now = Math.floor(Date.now() / 1000);
    if (Math.abs(now - env.ts) > TS_WINDOW) {
      return reject(res, 401, 'ts_skew', { skew: now - env.ts });
    }

    let payload;
    try {
      payload = decrypt(env);
    } catch (e) {
      return reject(res, 401, 'decrypt_failed', { err: e.message });
    }
    if (!payload || !payload.path || !payload.nonce) {
      return reject(res, 400, 'bad_payload', { keys: payload ? Object.keys(payload) : null });
    }
    if (!replayOk(payload.nonce)) {
      return reject(res, 401, 'replay');
    }

    if (!payload.key) {
      return reject(res, 400, 'missing_key');
    }

    // Pre-auth probes: APK polls /api/slot/status and /api/cooldown/status before user logs in
    // using placeholder keys ("SLOT_CHECK", "COOLDOWN", etc). Allow these without a real key.
    const PREAUTH_KEYS = new Set(['SLOT_CHECK', 'COOLDOWN', 'API_REQUEST']);
    const PREAUTH_PATHS = new Set(['/api/slot/status', '/api/cooldown/status', '/api/ping', '/api/config']);
    if (PREAUTH_KEYS.has(payload.key)) {
      if (!PREAUTH_PATHS.has(payload.path)) {
        return reject(res, 403, 'preauth_path_not_allowed', { path: payload.path });
      }
      // Synthesize a minimal "key row" for dispatch to use
      const fakeKey = { id: 0, key_value: payload.key, status: 'preauth', duration_type: 'preauth', max_devices: 0, assigned_to: null };
      try {
        const out = await dispatch(payload, fakeKey, req);
        return res.json(encrypt(out, env.kid));
      } catch (e) {
        console.error(`[x-gateway][PREAUTH-DISPATCH-ERR] path=${payload.path} err=${e.message}\n${e.stack}`);
        return reject(res, 500, 'preauth_dispatch_error', { err: e.message });
      }
    }

    const k = db.prepare('SELECT * FROM license_keys WHERE key_value = ?').get(payload.key);
    if (!k) {
      return reject(res, 404, 'key_not_found', { key: String(payload.key).substring(0, 8) + '...' });
    }
    if (k.status === 'revoked') {
      return reject(res, 403, 'key_revoked');
    }

    // Panel-level HMAC signature (X-Panel-Sig)
    const panelSig = req.get('X-Panel-Sig') || req.get('x-panel-sig') || '';
    if (HMAC_SECRET && panelSig) {
      const deviceId = payload.device_id || '';
      if (deviceId) {
        const expected = crypto.createHmac('sha256', HMAC_SECRET)
          .update(`${payload.key}|${deviceId}`).digest('hex');

        let sigValid = false;
        try {
          sigValid = panelSig.length === expected.length &&
            crypto.timingSafeEqual(Buffer.from(panelSig, 'hex'), Buffer.from(expected, 'hex'));
        } catch (_) { sigValid = false; }

        if (!sigValid) {
          console.warn(`[x-gateway] bad panel signature for key ${payload.key.substring(0, 8)}... (HMAC_REQUIRED=${HMAC_REQUIRED})`);
          if (HMAC_REQUIRED) {
            try { return res.json(encrypt({ ok: false, reason: 'bad_signature' }, env.kid)); }
            catch (e) { return reject(res, 500, 'encrypt_err_bad_sig', { err: e.message }); }
          }
        }
      }
    } else if (HMAC_REQUIRED && HMAC_SECRET) {
      console.warn(`[x-gateway] missing panel signature for key ${payload.key.substring(0, 8)}...`);
      try { return res.json(encrypt({ ok: false, reason: 'missing_signature' }, env.kid)); }
      catch (e) { return reject(res, 500, 'encrypt_err_missing_sig', { err: e.message }); }
    }

    let out;
    try {
      out = await dispatch(payload, k, req);
    } catch (e) {
      console.error(`[x-gateway][DISPATCH-ERROR] path=${payload.method} ${payload.path} key=${String(payload.key).substring(0,8)}... err=${e.message}\n${e.stack}`);
      return reject(res, 500, 'dispatch_error', { err: e.message });
    }

    try {
      return res.json(encrypt(out, env.kid));
    } catch (e) {
      console.error(`[x-gateway][ENCRYPT-ERROR] err=${e.message}\n${e.stack}`);
      return reject(res, 500, 'encrypt_error', { err: e.message });
    }
  } catch (e) {
    console.error(`[x-gateway][FATAL] err=${e.message}\n${e.stack}\nbody-keys=${envForLog ? Object.keys(envForLog) : 'none'}`);
    if (global.securityLogger) {
      try { global.securityLogger.error(`[x-gateway] fatal: ${e.message}`); } catch (_) {}
    }
    return reject(res, 500, 'server_error', { err: e.message });
  }
});

module.exports = router;
