/**
 * /api/cooldown — Per-key cooldown status (PROMPTV4 V2 FIX: HMAC-gated + uniform responses)
 * Reads license_keys.last_fire_at + cooldown_seconds
 */
const express = require('express');
const { db } = require('../db/database-v4');
const { hmacVerify, blockMiddleware } = require('../middleware/security');

const router = express.Router();

// PROMPTV4 V2 FIX: HMAC-gate /status and return uniform responses for valid/invalid keys
router.get('/status', blockMiddleware, hmacVerify, (req, res) => {
  const key = (req.query.key || '').toString().trim();
  if (!key) {
    // Uniform response (don't reveal if key exists or not)
    return res.json({ cooldown_active: false, cooldown_remaining_seconds: 0 });
  }

  const k = db.prepare('SELECT last_fire_at, cooldown_seconds FROM license_keys WHERE key_value = ?').get(key);
  
  // PROMPTV4 V2: Return same payload shape for invalid keys (oracle prevention)
  if (!k) {
    return res.json({ cooldown_active: false, cooldown_remaining_seconds: 0 });
  }

  const last = k.last_fire_at ? new Date(k.last_fire_at).getTime() : 0;
  const cd = (k.cooldown_seconds || 180);
  const remaining = Math.max(0, Math.ceil((last + cd * 1000 - Date.now()) / 1000));
  return res.json({ cooldown_active: remaining > 0, cooldown_remaining_seconds: remaining, cooldown_seconds: cd });
});

module.exports = router;
