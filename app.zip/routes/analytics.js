/**
 * Analytics & Monitoring Routes
 * Provides comprehensive usage statistics and insights
 */

const express = require('express');
const { db } = require('../db/database-v4');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/analytics/overview
 * Dashboard overview statistics (admin only)
 */
router.get('/overview', authRequired, (req, res) => {
  try {
    // Total users
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    
    // Active users (verified in last 7 days)
    const activeUsers = db.prepare(`
      SELECT COUNT(DISTINCT assigned_to) as count 
      FROM license_keys 
      WHERE last_verified >= datetime('now', '-7 days')
    `).get().count;

    // Total keys
    const totalKeys = db.prepare('SELECT COUNT(*) as count FROM license_keys').get().count;
    
    // Active keys
    const activeKeys = db.prepare(`
      SELECT COUNT(*) as count 
      FROM license_keys 
      WHERE status = 'active' 
        AND (duration_type = 'lifetime' OR expires_at > datetime('now'))
    `).get().count;

    // Total devices
    const totalDevices = db.prepare('SELECT COUNT(*) as count FROM device_bindings').get().count;

    // Active devices (last 24 hours)
    const activeDevices = db.prepare(`
      SELECT COUNT(*) as count 
      FROM device_bindings 
      WHERE last_active >= datetime('now', '-1 day')
    `).get().count;

    // Total APK versions
    const totalApks = db.prepare('SELECT COUNT(*) as count FROM apk_versions').get().count;

    // Latest APK
    const latestApk = db.prepare(`
      SELECT version_code, version_name, download_count 
      FROM apk_versions 
      ORDER BY version_code DESC 
      LIMIT 1
    `).get();

    // Events today
    const eventsToday = db.prepare(`
      SELECT COUNT(*) as count 
      FROM analytics_events 
      WHERE DATE(created_at) = DATE('now')
    `).get().count;

    // Key verifications today
    const verificationsToday = db.prepare(`
      SELECT COUNT(*) as count 
      FROM analytics_events 
      WHERE event_type = 'key_verified' 
        AND DATE(created_at) = DATE('now')
    `).get().count;

    res.json({
      success: true,
      overview: {
        users: {
          total: totalUsers,
          active: activeUsers
        },
        keys: {
          total: totalKeys,
          active: activeKeys
        },
        devices: {
          total: totalDevices,
          active_24h: activeDevices
        },
        apks: {
          total: totalApks,
          latest: latestApk
        },
        activity: {
          events_today: eventsToday,
          verifications_today: verificationsToday
        }
      }
    });
  } catch (err) {
    console.error('Analytics error:', err);
    res.status(500).json({ error: 'analytics_failed' });
  }
});

/**
 * GET /api/analytics/keys
 * Key usage analytics (admin only)
 */
router.get('/keys', authRequired, (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;

    // Keys by status
    const byStatus = db.prepare(`
      SELECT status, COUNT(*) as count 
      FROM license_keys 
      GROUP BY status
    `).all();

    // Keys by tier
    const byTier = db.prepare(`
      SELECT tier, COUNT(*) as count 
      FROM license_keys 
      GROUP BY tier
    `).all();

    // Keys by duration type
    const byDuration = db.prepare(`
      SELECT duration_type, COUNT(*) as count 
      FROM license_keys 
      GROUP BY duration_type
    `).all();

    // Expiring soon (next 7 days)
    const expiringSoon = db.prepare(`
      SELECT COUNT(*) as count 
      FROM license_keys 
      WHERE expires_at BETWEEN datetime('now') AND datetime('now', '+7 days')
        AND status = 'active'
    `).get().count;

    // Keys created per day (last N days)
    const createdDaily = db.prepare(`
      SELECT DATE(created_at) as date, COUNT(*) as count 
      FROM license_keys 
      WHERE created_at >= datetime('now', '-${days} days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all();

    // Top users by key count
    const topUsers = db.prepare(`
      SELECT u.username, COUNT(k.id) as key_count
      FROM users u
      LEFT JOIN license_keys k ON k.assigned_to = u.id
      GROUP BY u.id
      ORDER BY key_count DESC
      LIMIT 10
    `).all();

    res.json({
      success: true,
      keys: {
        by_status: byStatus,
        by_tier: byTier,
        by_duration: byDuration,
        expiring_soon: expiringSoon,
        created_daily: createdDaily,
        top_users: topUsers
      }
    });
  } catch (err) {
    console.error('Key analytics error:', err);
    res.status(500).json({ error: 'analytics_failed' });
  }
});

/**
 * GET /api/analytics/devices
 * Device usage analytics (admin only)
 */
router.get('/devices', authRequired, (req, res) => {
  try {
    // Devices by type
    const byType = db.prepare(`
      SELECT device_type, COUNT(*) as count 
      FROM device_bindings 
      GROUP BY device_type
    `).all();

    // Devices by brand
    const byBrand = db.prepare(`
      SELECT device_brand, COUNT(*) as count 
      FROM device_bindings 
      WHERE device_brand IS NOT NULL
      GROUP BY device_brand
      ORDER BY count DESC
      LIMIT 10
    `).all();

    // Devices by Android version
    const byAndroid = db.prepare(`
      SELECT android_version, COUNT(*) as count 
      FROM device_bindings 
      WHERE android_version IS NOT NULL
      GROUP BY android_version
      ORDER BY count DESC
    `).all();

    // Active devices by day (last 30 days)
    const activeDaily = db.prepare(`
      SELECT DATE(last_active) as date, COUNT(DISTINCT device_id) as count 
      FROM device_bindings 
      WHERE last_active >= datetime('now', '-30 days')
      GROUP BY DATE(last_active)
      ORDER BY date DESC
    `).all();

    // Devices per key distribution
    const devicesPerKey = db.prepare(`
      SELECT 
        CASE 
          WHEN device_count = 1 THEN '1 device'
          WHEN device_count BETWEEN 2 AND 5 THEN '2-5 devices'
          WHEN device_count BETWEEN 6 AND 10 THEN '6-10 devices'
          ELSE '11+ devices'
        END as range,
        COUNT(*) as key_count
      FROM (
        SELECT key_id, COUNT(*) as device_count
        FROM device_bindings
        GROUP BY key_id
      )
      GROUP BY range
    `).all();

    res.json({
      success: true,
      devices: {
        by_type: byType,
        by_brand: byBrand,
        by_android: byAndroid,
        active_daily: activeDaily,
        devices_per_key: devicesPerKey
      }
    });
  } catch (err) {
    console.error('Device analytics error:', err);
    res.status(500).json({ error: 'analytics_failed' });
  }
});

/**
 * GET /api/analytics/versions
 * APK version adoption analytics (admin only)
 */
router.get('/versions', authRequired, (req, res) => {
  try {
    // All versions with download counts
    const versions = db.prepare(`
      SELECT 
        version_code, 
        version_name, 
        channel,
        download_count,
        created_at,
        is_active
      FROM apk_versions 
      ORDER BY version_code DESC
    `).all();

    // Active app versions (from device_bindings)
    const activeVersions = db.prepare(`
      SELECT app_version, COUNT(*) as count 
      FROM device_bindings 
      WHERE app_version IS NOT NULL
      GROUP BY app_version
      ORDER BY count DESC
    `).all();

    // Download trends (last 30 days)
    const downloadTrends = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as downloads
      FROM analytics_events
      WHERE event_type = 'apk_download'
        AND created_at >= datetime('now', '-30 days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all();

    res.json({
      success: true,
      versions: {
        all_versions: versions,
        active_versions: activeVersions,
        download_trends: downloadTrends
      }
    });
  } catch (err) {
    console.error('Version analytics error:', err);
    res.status(500).json({ error: 'analytics_failed' });
  }
});

/**
 * GET /api/analytics/events
 * Event log analytics (admin only)
 */
router.get('/events', authRequired, (req, res) => {
  try {
    const days = parseInt(req.query.days) || 7;
    const limit = parseInt(req.query.limit) || 100;

    // Events by type
    const byType = db.prepare(`
      SELECT event_type, COUNT(*) as count 
      FROM analytics_events 
      WHERE created_at >= datetime('now', '-${days} days')
      GROUP BY event_type
      ORDER BY count DESC
    `).all();

    // Events timeline (daily)
    const timeline = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        event_type,
        COUNT(*) as count
      FROM analytics_events
      WHERE created_at >= datetime('now', '-${days} days')
      GROUP BY DATE(created_at), event_type
      ORDER BY date DESC, count DESC
    `).all();

    // Recent events
    const recent = db.prepare(`
      SELECT 
        e.*,
        u.username as user_username
      FROM analytics_events e
      LEFT JOIN users u ON u.id = e.user_id
      ORDER BY e.created_at DESC
      LIMIT ${limit}
    `).all();

    res.json({
      success: true,
      events: {
        by_type: byType,
        timeline: timeline,
        recent: recent
      }
    });
  } catch (err) {
    console.error('Event analytics error:', err);
    res.status(500).json({ error: 'analytics_failed' });
  }
});

module.exports = router;
