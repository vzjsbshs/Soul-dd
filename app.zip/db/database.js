// FIX A10: Re-export from database-v4.js to avoid dual WAL connections
module.exports = require('./database-v4');
