const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'panel.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initSchema() {
  // Original schema initialization (kept for backward compatibility)
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      approved_by INTEGER REFERENCES users(id),
      promo_used TEXT,
      token_version INTEGER DEFAULT 0,
      must_change_password INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS promo_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      created_by INTEGER REFERENCES users(id),
      max_uses INTEGER DEFAULT 1,
      uses_count INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS license_keys (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key_value TEXT UNIQUE NOT NULL,
      assigned_to INTEGER REFERENCES users(id),
      created_by INTEGER REFERENCES users(id),
      device_id TEXT,
      expires_at DATETIME NOT NULL,
      status TEXT DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_verified DATETIME,
      duration_type TEXT DEFAULT 'days',
      duration_value INTEGER DEFAULT 30,
      max_devices INTEGER DEFAULT 1,
      features TEXT,
      metadata TEXT,
      tier TEXT DEFAULT 'standard'
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER REFERENCES users(id),
      action TEXT NOT NULL,
      target_id INTEGER,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS api_calls (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key_id INTEGER REFERENCES license_keys(id),
      key_value TEXT NOT NULL,
      ip TEXT,
      port TEXT,
      duration TEXT,
      upstream_status INTEGER,
      ok INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_keys_assigned ON license_keys(assigned_to);
    CREATE INDEX IF NOT EXISTS idx_keys_creator ON license_keys(created_by);
    CREATE INDEX IF NOT EXISTS idx_users_approved_by ON users(approved_by);
    CREATE INDEX IF NOT EXISTS idx_api_calls_key ON api_calls(key_id);
    CREATE INDEX IF NOT EXISTS idx_api_calls_created ON api_calls(created_at);
  `);

  // Per-key cooldown columns (original migration)
  const cols = db.prepare("PRAGMA table_info(license_keys)").all().map(c => c.name);
  if (!cols.includes('last_fire_at')) {
    db.exec("ALTER TABLE license_keys ADD COLUMN last_fire_at DATETIME");
  }
  if (!cols.includes('cooldown_seconds')) {
    db.exec("ALTER TABLE license_keys ADD COLUMN cooldown_seconds INTEGER DEFAULT 180");
  }
}

function audit(actorId, action, targetId = null, details = null) {
  db.prepare('INSERT INTO audit_log (actor_id, action, target_id, details) VALUES (?, ?, ?, ?)')
    .run(actorId, action, targetId, details ? JSON.stringify(details) : null);
}

// ═══════════════════════════════════════════════════════════
// NEW HELPER FUNCTIONS FOR v4 FEATURES
// ═══════════════════════════════════════════════════════════

/**
 * Get app configuration value
 */
function getConfig(key) {
  const row = db.prepare('SELECT config_value, config_type FROM app_configs WHERE config_key = ? AND is_active = 1').get(key);
  if (!row) return null;
  
  // Parse based on type
  if (row.config_type === 'boolean') return row.config_value === '1' || row.config_value === 'true';
  if (row.config_type === 'number') return Number(row.config_value);
  if (row.config_type === 'json') return JSON.parse(row.config_value);
  return row.config_value; // string
}

/**
 * Set app configuration value
 */
function setConfig(key, value, userId = null) {
  const row = db.prepare('SELECT config_type FROM app_configs WHERE config_key = ?').get(key);
  if (!row) return false;
  
  let stringValue = String(value);
  if (row.config_type === 'json') stringValue = JSON.stringify(value);
  
  db.prepare('UPDATE app_configs SET config_value = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ? WHERE config_key = ?')
    .run(stringValue, userId, key);
  return true;
}

/**
 * Check if feature flag is enabled
 */
function isFeatureEnabled(flagKey) {
  const row = db.prepare('SELECT flag_value FROM feature_flags WHERE flag_key = ?').get(flagKey);
  return row ? Boolean(row.flag_value) : false;
}

/**
 * Get device bindings for a key
 */
function getDeviceBindings(keyId) {
  return db.prepare(`
    SELECT * FROM device_bindings 
    WHERE key_id = ? 
    ORDER BY last_active DESC
  `).all(keyId);
}

/**
 * Check if device can be bound (within limit)
 */
function canBindDevice(keyId) {
  const key = db.prepare('SELECT max_devices FROM license_keys WHERE id = ?').get(keyId);
  if (!key) return false;
  
  const currentDevices = db.prepare('SELECT COUNT(*) as count FROM device_bindings WHERE key_id = ? AND approved = 1').get(keyId);
  return currentDevices.count < key.max_devices;
}

/**
 * Bind device to key
 */
function bindDevice(keyId, deviceId, deviceInfo = {}) {
  try {
    db.prepare(`
      INSERT INTO device_bindings (
        key_id, device_id, device_name, device_type, device_model, 
        device_brand, android_version, app_version, ip_address, approved
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `).run(
      keyId,
      deviceId,
      deviceInfo.device_name || null,
      deviceInfo.device_type || null,
      deviceInfo.device_model || null,
      deviceInfo.device_brand || null,
      deviceInfo.android_version || null,
      deviceInfo.app_version || null,
      deviceInfo.ip_address || null
    );
    return true;
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT') return false;
    throw err;
  }
}

/**
 * Update device last active timestamp
 */
function updateDeviceActivity(keyId, deviceId) {
  db.prepare('UPDATE device_bindings SET last_active = CURRENT_TIMESTAMP WHERE key_id = ? AND device_id = ?')
    .run(keyId, deviceId);
}

/**
 * Check if maintenance mode is active
 */
function isMaintenanceMode() {
  return getConfig('maintenance_mode') === true;
}

/**
 * Check if app kill switch is active
 */
function isKillSwitchActive() {
  return getConfig('app_kill_switch') === true;
}

/**
 * Log analytics event
 */
function logEvent(eventType, userId = null, keyId = null, deviceId = null, metadata = null) {
  db.prepare(`
    INSERT INTO analytics_events (event_type, user_id, key_id, device_id, metadata)
    VALUES (?, ?, ?, ?, ?)
  `).run(eventType, userId, keyId, deviceId, metadata ? JSON.stringify(metadata) : null);
}

/**
 * Create notification for user
 */
function createNotification(userId, title, message, type = 'info') {
  db.prepare(`
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (?, ?, ?, ?)
  `).run(userId, title, message, type);
}

/**
 * Get latest APK version for a channel
 */
function getLatestApk(channel = 'stable') {
  return db.prepare(`
    SELECT * FROM apk_versions 
    WHERE channel = ? AND is_active = 1 
    ORDER BY version_code DESC 
    LIMIT 1
  `).get(channel);
}

module.exports = { 
  db, 
  initSchema, 
  audit,
  // v4 functions
  getConfig,
  setConfig,
  isFeatureEnabled,
  getDeviceBindings,
  canBindDevice,
  bindDevice,
  updateDeviceActivity,
  isMaintenanceMode,
  isKillSwitchActive,
  logEvent,
  createNotification,
  getLatestApk
};
