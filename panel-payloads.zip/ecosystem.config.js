module.exports = {
  apps: [{
    name: 'panel',
    script: 'app.js',
    cwd: '/home/ubuntu/panel',
    env: { NODE_ENV: 'production' },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '300M',
    error_file: '/home/ubuntu/logs/panel-err.log',
    out_file:   '/home/ubuntu/logs/panel-out.log',
    merge_logs: true,
    time: true,
  }]
};
