#!/bin/bash
# PROMPTV4 Post-APK Deployment Script
# Run this after the updated APK with HMAC support has been released
# and 90% adoption is confirmed

set -e

PANEL_DIR="/home/ubuntu/panel"
BACKUP_DIR="/home/ubuntu/backups/promptv4-hmac-enforcement-$(date +%Y%m%d_%H%M%S)"

echo "=== PROMPTV4: Enable Strict HMAC Enforcement ==="
echo ""
echo "⚠️  WARNING: This will break any clients not sending X-Request-Sig header"
echo "Press CTRL+C to abort, or ENTER to continue..."
read

echo "Creating backup..."
mkdir -p "$BACKUP_DIR"
cp "$PANEL_DIR/.env" "$BACKUP_DIR/"

echo "Updating .env to set HMAC_REQUIRED=true..."
cd "$PANEL_DIR"
sed -i 's/^HMAC_REQUIRED=false/HMAC_REQUIRED=true/' .env

echo "Verifying change..."
grep HMAC_REQUIRED .env

echo ""
echo "Restarting panel..."
# Find the running node process
PID=$(ps aux | grep 'node app.js' | grep -v grep | awk '{print $2}')
if [ -n "$PID" ]; then
  echo "Killing old process (PID: $PID)..."
  kill $PID
  sleep 2
fi

echo "Starting new process..."
nohup node app.js > /tmp/panel.log 2>&1 &
sleep 3

echo "Checking status..."
NEW_PID=$(ps aux | grep 'node app.js' | grep -v grep | awk '{print $2}')
if [ -n "$NEW_PID" ]; then
  echo "✅ Panel restarted successfully (PID: $NEW_PID)"
  tail -10 /tmp/panel.log
else
  echo "❌ Panel failed to start! Check /tmp/panel.log"
  exit 1
fi

echo ""
echo "=== HMAC Enforcement Enabled ==="
echo ""
echo "Next steps:"
echo "1. Monitor security logs: tail -f /home/ubuntu/logs/security-*.log | grep hmac"
echo "2. Watch for 'missing_signature' or 'bad_signature' errors"
echo "3. If legacy clients are still accessing, temporarily revert:"
echo "   sed -i 's/HMAC_REQUIRED=true/HMAC_REQUIRED=false/' .env && [restart panel]"
echo ""
echo "Backup saved to: $BACKUP_DIR"
