require('dotenv').config();
const bcrypt = require('bcrypt');
const { db, initSchema } = require('./db/database');

async function updateOwner() {
  initSchema();
  
  console.log('=== Current Owner Account ===');
  const owner = db.prepare("SELECT id, username, role FROM users WHERE username = 'owner'").get();
  console.log(owner);
  
  if (owner) {
    console.log('\n=== Updating Existing Owner Account ===');
    const hashedPassword = await bcrypt.hash('soulpapa@88810', 12);
    
    // Update the existing owner account
    db.prepare(`
      UPDATE users 
      SET username = ?, 
          password_hash = ?, 
          must_change_password = 0
      WHERE username = 'owner'
    `).run('soulpapa', hashedPassword);
    
    console.log('✅ Owner account updated successfully!');
  } else {
    console.log('\n=== Creating New Owner Account ===');
    const hashedPassword = await bcrypt.hash('soulpapa@88810', 12);
    
    db.prepare(`
      INSERT INTO users (username, password_hash, role, status, must_change_password, created_at)
      VALUES (?, ?, 'owner', 'approved', 0, datetime('now'))
    `).run('soulpapa', hashedPassword);
    
    console.log('✅ New owner account created successfully!');
  }
  
  console.log('\n=== Verification ===');
  const newOwner = db.prepare("SELECT id, username, role, must_change_password FROM users WHERE username = 'soulpapa'").get();
  console.log(newOwner);
  
  console.log('\n============================================');
  console.log('  NEW OWNER CREDENTIALS:');
  console.log('    username: soulpapa');
  console.log('    password: soulpapa@88810');
  console.log('    URL: https://soul-ddos-domain.shop/login');
  console.log('============================================');
}

updateOwner().catch(console.error);
