/**
 * Migration: Add online slot + cooldown management to panel DB
 * Adds global_state table and new columns to license_keys
 */
const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'panel.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

console.log('Starting migration: online slot + cooldown system');

try {
  // 1. Create global_state table for slot management
  db.exec(`
    CREATE TABLE IF NOT EXISTS global_state (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);
  console.log('✓ Created global_state table');

  // 2. Initialize slot state (free on first run)
  const checkSlot = db.prepare("SELECT value FROM global_state WHERE key = 'slot_locked_until'").get();
  if (!checkSlot) {
    db.prepare("INSERT INTO global_state (key, value) VALUES (?, ?)").run('slot_locked_until', null);
    db.prepare("INSERT INTO global_state (key, value) VALUES (?, ?)").run('slot_fired_by', null);
    console.log('✓ Initialized slot state (free)');
  } else {
    console.log('✓ Slot state already exists');
  }

  // 3. Add new columns to license_keys (idempotent)
  const cols = db.prepare("PRAGMA table_info(license_keys)").all().map(c => c.name);
  
  if (!cols.includes('cooldown_ends_at')) {
    db.exec("ALTER TABLE license_keys ADD COLUMN cooldown_ends_at DATETIME DEFAULT NULL");
    console.log('✓ Added cooldown_ends_at column');
  } else {
    console.log('✓ cooldown_ends_at column already exists');
  }

  // Note: last_fire_at and cooldown_seconds already exist from v3
  // We'll repurpose them for the new system
  console.log('✓ Verified last_fire_at and cooldown_seconds columns exist');

  console.log('\n✅ Migration complete!');
  console.log('Next steps:');
  console.log('  1. Update routes/fire.js with new slot logic');
  console.log('  2. Add /api/slot/status endpoint');
  console.log('  3. Add /api/cooldown/status endpoint');
  console.log('  4. Restart panel: pm2 restart panel');

} catch (err) {
  console.error('❌ Migration failed:', err.message);
  process.exit(1);
} finally {
  db.close();
}
