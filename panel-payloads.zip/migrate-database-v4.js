/**
 * Soul DD Panel - Database Migration v4
 * Adds support for 400+ new features:
 * - Multi-device licensing
 * - APK version management
 * - Remote configuration
 * - Maintenance windows
 * - Analytics & notifications
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', 'panel', 'panel.db');
const BACKUP_DIR = path.join(__dirname, '..', 'backups');

console.log('╔════════════════════════════════════════════════════════════╗');
console.log('║   SOUL DD PANEL - DATABASE MIGRATION v4                   ║');
console.log('╚════════════════════════════════════════════════════════════╝\n');

// Backup before migration
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const backupPath = path.join(BACKUP_DIR, `panel-pre-migration-${timestamp}.db`);

try {
    if (fs.existsSync(DB_PATH)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
        fs.copyFileSync(DB_PATH, backupPath);
        console.log(`✓ Database backed up to: ${backupPath}\n`);
    } else {
        console.log('⚠ No existing database found, creating new one...\n');
    }
} catch (err) {
    console.error('✗ Backup failed:', err.message);
    process.exit(1);
}

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

console.log('Starting migration...\n');

try {
    // Start transaction
    db.exec('BEGIN TRANSACTION');

    // ═══════════════════════════════════════════════════════════
    // 1. DEVICE BINDINGS TABLE (Multi-device support)
    // ═══════════════════════════════════════════════════════════
    console.log('[1/10] Creating device_bindings table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS device_bindings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_id INTEGER NOT NULL,
            device_id TEXT NOT NULL,
            device_name TEXT,
            device_type TEXT,
            device_model TEXT,
            device_brand TEXT,
            android_version TEXT,
            app_version TEXT,
            first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address TEXT,
            location TEXT,
            approved INTEGER DEFAULT 1,
            notes TEXT,
            FOREIGN KEY (key_id) REFERENCES license_keys(id) ON DELETE CASCADE,
            UNIQUE(key_id, device_id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_device_bindings_key ON device_bindings(key_id);
        CREATE INDEX IF NOT EXISTS idx_device_bindings_device ON device_bindings(device_id);
        CREATE INDEX IF NOT EXISTS idx_device_bindings_last_active ON device_bindings(last_active);
    `);
    console.log('  ✓ device_bindings table created\n');

    // ═══════════════════════════════════════════════════════════
    // 2. APK VERSIONS TABLE (Version management)
    // ═══════════════════════════════════════════════════════════
    console.log('[2/10] Creating apk_versions table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS apk_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version_code INTEGER NOT NULL UNIQUE,
            version_name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size INTEGER,
            file_hash TEXT,
            channel TEXT DEFAULT 'stable',
            min_sdk INTEGER DEFAULT 21,
            target_sdk INTEGER DEFAULT 35,
            release_notes TEXT,
            is_active INTEGER DEFAULT 1,
            force_update INTEGER DEFAULT 0,
            rollout_percentage INTEGER DEFAULT 100,
            download_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_apk_versions_code ON apk_versions(version_code);
        CREATE INDEX IF NOT EXISTS idx_apk_versions_channel ON apk_versions(channel);
        CREATE INDEX IF NOT EXISTS idx_apk_versions_active ON apk_versions(is_active);
    `);
    console.log('  ✓ apk_versions table created\n');

    // ═══════════════════════════════════════════════════════════
    // 3. APP CONFIGS TABLE (Remote configuration)
    // ═══════════════════════════════════════════════════════════
    console.log('[3/10] Creating app_configs table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS app_configs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_key TEXT NOT NULL UNIQUE,
            config_value TEXT,
            config_type TEXT DEFAULT 'string',
            description TEXT,
            is_active INTEGER DEFAULT 1,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by INTEGER,
            FOREIGN KEY (updated_by) REFERENCES users(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_app_configs_key ON app_configs(config_key);
        CREATE INDEX IF NOT EXISTS idx_app_configs_active ON app_configs(is_active);
    `);
    console.log('  ✓ app_configs table created\n');

    // ═══════════════════════════════════════════════════════════
    // 4. MAINTENANCE WINDOWS TABLE
    // ═══════════════════════════════════════════════════════════
    console.log('[4/10] Creating maintenance_windows table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS maintenance_windows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time DATETIME NOT NULL,
            end_time DATETIME NOT NULL,
            message TEXT,
            message_lang TEXT DEFAULT 'en',
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_maintenance_active ON maintenance_windows(is_active);
        CREATE INDEX IF NOT EXISTS idx_maintenance_times ON maintenance_windows(start_time, end_time);
    `);
    console.log('  ✓ maintenance_windows table created\n');

    // ═══════════════════════════════════════════════════════════
    // 5. NOTIFICATIONS TABLE
    // ═══════════════════════════════════════════════════════════
    console.log('[5/10] Creating notifications table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            type TEXT DEFAULT 'info',
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        
        CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
        CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);
        CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at);
    `);
    console.log('  ✓ notifications table created\n');

    // ═══════════════════════════════════════════════════════════
    // 6. ANALYTICS EVENTS TABLE
    // ═══════════════════════════════════════════════════════════
    console.log('[6/10] Creating analytics_events table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS analytics_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            user_id INTEGER,
            key_id INTEGER,
            device_id TEXT,
            metadata TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (key_id) REFERENCES license_keys(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_analytics_type ON analytics_events(event_type);
        CREATE INDEX IF NOT EXISTS idx_analytics_user ON analytics_events(user_id);
        CREATE INDEX IF NOT EXISTS idx_analytics_key ON analytics_events(key_id);
        CREATE INDEX IF NOT EXISTS idx_analytics_created ON analytics_events(created_at);
    `);
    console.log('  ✓ analytics_events table created\n');

    // ═══════════════════════════════════════════════════════════
    // 7. FEATURE FLAGS TABLE
    // ═══════════════════════════════════════════════════════════
    console.log('[7/10] Creating feature_flags table...');
    db.exec(`
        CREATE TABLE IF NOT EXISTS feature_flags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flag_key TEXT NOT NULL UNIQUE,
            flag_value INTEGER DEFAULT 0,
            description TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by INTEGER,
            FOREIGN KEY (updated_by) REFERENCES users(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_feature_flags_key ON feature_flags(flag_key);
    `);
    console.log('  ✓ feature_flags table created\n');

    // ═══════════════════════════════════════════════════════════
    // 8. ALTER LICENSE_KEYS TABLE (Add new columns)
    // ═══════════════════════════════════════════════════════════
    console.log('[8/10] Altering license_keys table...');
    
    const existingColumns = db.prepare("PRAGMA table_info(license_keys)").all().map(c => c.name);
    
    const newColumns = [
        { name: 'duration_type', sql: "ALTER TABLE license_keys ADD COLUMN duration_type TEXT DEFAULT 'days'" },
        { name: 'duration_value', sql: "ALTER TABLE license_keys ADD COLUMN duration_value INTEGER DEFAULT 30" },
        { name: 'max_devices', sql: "ALTER TABLE license_keys ADD COLUMN max_devices INTEGER DEFAULT 1" },
        { name: 'features', sql: "ALTER TABLE license_keys ADD COLUMN features TEXT" },
        { name: 'metadata', sql: "ALTER TABLE license_keys ADD COLUMN metadata TEXT" },
        { name: 'tier', sql: "ALTER TABLE license_keys ADD COLUMN tier TEXT DEFAULT 'standard'" },
    ];

    newColumns.forEach(col => {
        if (!existingColumns.includes(col.name)) {
            db.exec(col.sql);
            console.log(`  ✓ Added column: ${col.name}`);
        } else {
            console.log(`  ⊙ Column already exists: ${col.name}`);
        }
    });
    console.log('  ✓ license_keys table updated\n');

    // ═══════════════════════════════════════════════════════════
    // 9. MIGRATE EXISTING DATA
    // ═══════════════════════════════════════════════════════════
    console.log('[9/10] Migrating existing data...');
    
    // Migrate existing device_id to device_bindings
    const existingKeys = db.prepare(`
        SELECT id, device_id, last_verified 
        FROM license_keys 
        WHERE device_id IS NOT NULL AND device_id != ''
    `).all();

    let migratedDevices = 0;
    existingKeys.forEach(key => {
        try {
            db.prepare(`
                INSERT OR IGNORE INTO device_bindings (key_id, device_id, first_seen, last_active, approved)
                VALUES (?, ?, CURRENT_TIMESTAMP, ?, 1)
            `).run(key.id, key.device_id, key.last_verified || new Date().toISOString());
            migratedDevices++;
        } catch (err) {
            console.log(`  ⚠ Failed to migrate device for key ${key.id}: ${err.message}`);
        }
    });
    console.log(`  ✓ Migrated ${migratedDevices} existing device bindings\n`);

    // ═══════════════════════════════════════════════════════════
    // 10. INSERT DEFAULT CONFIGURATIONS
    // ═══════════════════════════════════════════════════════════
    console.log('[10/10] Inserting default configurations...');
    
    const defaultConfigs = [
        ['maintenance_mode', '0', 'boolean', 'Global maintenance mode status'],
        ['maintenance_message', 'System under maintenance', 'string', 'Maintenance message'],
        ['app_kill_switch', '0', 'boolean', 'Global app kill switch'],
        ['force_update_enabled', '0', 'boolean', 'Force update requirement'],
        ['min_supported_version', '1', 'number', 'Minimum supported app version'],
        ['telegram_contact', '@soulcracks_owner', 'string', 'Telegram contact for support'],
        ['api_base_url', 'https://soul-ddos-domain.shop/api', 'string', 'API base URL'],
    ];

    defaultConfigs.forEach(([key, value, type, desc]) => {
        try {
            db.prepare(`
                INSERT OR IGNORE INTO app_configs (config_key, config_value, config_type, description)
                VALUES (?, ?, ?, ?)
            `).run(key, value, type, desc);
            console.log(`  ✓ Added config: ${key}`);
        } catch (err) {
            console.log(`  ⊙ Config exists: ${key}`);
        }
    });

    // Insert default feature flags
    const defaultFlags = [
        ['multi_device_enabled', 1, 'Enable multi-device support'],
        ['apk_auto_update', 1, 'Enable automatic APK updates'],
        ['analytics_enabled', 1, 'Enable analytics tracking'],
        ['notifications_enabled', 1, 'Enable notification system'],
    ];

    defaultFlags.forEach(([key, value, desc]) => {
        try {
            db.prepare(`
                INSERT OR IGNORE INTO feature_flags (flag_key, flag_value, description)
                VALUES (?, ?, ?)
            `).run(key, value, desc);
            console.log(`  ✓ Added flag: ${key}`);
        } catch (err) {
            console.log(`  ⊙ Flag exists: ${key}`);
        }
    });

    console.log('  ✓ Default configurations inserted\n');

    // Commit transaction
    db.exec('COMMIT');

    console.log('╔════════════════════════════════════════════════════════════╗');
    console.log('║   MIGRATION COMPLETED SUCCESSFULLY! ✓                      ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    // Show summary
    console.log('Database Summary:');
    console.log('─────────────────────────────────────────────────────────────');
    
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
    console.log(`Total tables: ${tables.length}`);
    tables.forEach(t => console.log(`  • ${t.name}`));
    
    console.log('\nNew tables added:');
    console.log('  • device_bindings');
    console.log('  • apk_versions');
    console.log('  • app_configs');
    console.log('  • maintenance_windows');
    console.log('  • notifications');
    console.log('  • analytics_events');
    console.log('  • feature_flags');
    
    console.log('\nBackup location:', backupPath);
    console.log('─────────────────────────────────────────────────────────────\n');

} catch (err) {
    console.error('\n✗ Migration failed:', err.message);
    console.error(err.stack);
    db.exec('ROLLBACK');
    console.log('\n⚠ Transaction rolled back. Database unchanged.');
    process.exit(1);
} finally {
    db.close();
}
