require('dotenv').config();
const bcrypt = require('bcrypt');
const { db, initSchema } = require('./db/database');

initSchema();

const existing = db.prepare("SELECT id FROM users WHERE username = 'owner'").get();
if (existing) {
  console.log('Owner account already exists. Skipping seed.');
  process.exit(0);
}

const password = 'Admin@1234';
const hash = bcrypt.hashSync(password, 12);
db.prepare(`INSERT INTO users (username, password_hash, role, status, must_change_password)
            VALUES (?, ?, 'owner', 'approved', 1)`).run('owner', hash);

console.log('============================================');
console.log('  TrafficCapture Panel — Database Initialised');
console.log('============================================');
console.log('  Default Owner Credentials:');
console.log('    username: owner');
console.log('    password: Admin@1234');
console.log('  >>> CHANGE PASSWORD ON FIRST LOGIN <<<');
console.log('============================================');
