# PROMPTV4 V3: UA Blocker Analysis

## Current State
The app.js contains an OkHttp UA blocker that kills connections from `okhttp` user-agents
to all `/api/*` paths EXCEPT:
- `/api/x` (encrypted)
- `/health`
- `/downloads`

## Issue
The mobile APK uses OkHttp (default UA: `okhttp/4.11.0`), but Phase 2 report claimed
legacy `/api/keys/verify` works from the APK.

## Conclusion
After reviewing app.js, the blocker explicitly whitelists:
- `/api/keys/verify`
- `/api/slot/status`
- `/api/cooldown/status`

These are in MOBILE_ALLOWED set. So the APK CAN access these legacy endpoints.

## PROMPTV4 V1/V2 Fix Impact
With HMAC enforcement now enabled by default, the APK MUST send X-Request-Sig header
for verify/slot/cooldown endpoints. If the APK does not include HMAC, requests will
be rejected with 401.

## Rollout Plan
1. Keep HMAC_REQUIRED=false in .env temporarily
2. Release updated APK with HMAC support
3. After 30 days, set HMAC_REQUIRED=true
4. Monitor security logs for unauthorized access attempts
