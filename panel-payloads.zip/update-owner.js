require('dotenv').config();
const bcrypt = require('bcrypt');
const { db, initSchema } = require('./db/database');

async function updateOwner() {
  initSchema();
  
  console.log('=== Current Owner Accounts ===');
  const owners = db.prepare("SELECT id, username, role FROM users WHERE role = 'owner'").all();
  console.log(owners);
  
  console.log('\n=== Creating New Owner Account ===');
  const hashedPassword = await bcrypt.hash('soulpapa@88810', 12);
  
  // Delete old owner accounts
  db.prepare('DELETE FROM users WHERE username = ?').run('owner');
  db.prepare('DELETE FROM users WHERE username = ?').run('soulpapa');
  
  // Insert new owner
  const result = db.prepare(`
    INSERT INTO users (username, password_hash, role, status, must_change_password, created_at)
    VALUES (?, ?, 'owner', 'approved', 0, datetime('now'))
  `).run('soulpapa', hashedPassword);
  
  console.log('✅ New owner account created successfully!');
  console.log('Username: soulpapa');
  console.log('Password: soulpapa@88810');
  console.log('Role: owner');
  console.log('ID:', result.lastInsertRowid);
  
  console.log('\n=== Verification ===');
  const newOwners = db.prepare("SELECT id, username, role, must_change_password FROM users WHERE role = 'owner'").all();
  console.log(newOwners);
  
  console.log('\n============================================');
  console.log('  NEW OWNER CREDENTIALS:');
  console.log('    username: soulpapa');
  console.log('    password: soulpapa@88810');
  console.log('============================================');
}

updateOwner().catch(console.error);
