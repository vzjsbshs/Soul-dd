/**
 * PROMPTV4 V5 FIX: Migrate existing audit_log entries to mask key_values in details
 */
const Database = require('better-sqlite3');

const dbPath = '/home/ubuntu/panel/panel.db';
const db = new Database(dbPath);

console.log('=== PROMPTV4 V5: Migrating audit_log to mask key_values ===');

// Find all key_deleted entries with full key_value in details
const rows = db.prepare(`
  SELECT id, details FROM audit_log 
  WHERE action = 'key_deleted' AND details LIKE '%key_value%'
`).all();

console.log(`Found ${rows.length} audit entries to migrate`);

let migrated = 0;
for (const row of rows) {
  try {
    const details = JSON.parse(row.details);
    if (details.key_value && details.key_value.length > 4) {
      // Replace with last-4 only
      const masked = { ...details, key_last4: details.key_value.slice(-4) };
      delete masked.key_value;
      db.prepare('UPDATE audit_log SET details = ? WHERE id = ?')
        .run(JSON.stringify(masked), row.id);
      migrated++;
    }
  } catch (e) {
    console.warn(`Failed to migrate row ${row.id}: ${e.message}`);
  }
}

console.log(`Successfully migrated ${migrated} audit entries`);
db.close();
