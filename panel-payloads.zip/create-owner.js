const bcrypt = require('bcrypt');
const Database = require('better-sqlite3');

async function createOwner() {
  const db = new Database('/home/ubuntu/panel/db/soul.db');
  
  console.log('=== Current Users ===');
  const users = db.prepare('SELECT id, username, role FROM users').all();
  console.log(users);
  
  console.log('\n=== Creating New Owner Account ===');
  const hashedPassword = await bcrypt.hash('soulpapa@88810', 12);
  
  // Delete old accounts
  db.prepare('DELETE FROM users WHERE username = ?').run('owner');
  db.prepare('DELETE FROM users WHERE username = ?').run('soulpapa');
  
  // Insert new owner
  const result = db.prepare(`
    INSERT INTO users (username, password, role, must_change_password, created_at)
    VALUES (?, ?, ?, ?, datetime('now'))
  `).run('soulpapa', hashedPassword, 'owner', 0);
  
  console.log('✅ New owner account created successfully!');
  console.log('Username: soulpapa');
  console.log('Password: soulpapa@88810');
  console.log('Role: owner');
  console.log('ID:', result.lastInsertRowid);
  
  console.log('\n=== Verification ===');
  const newUsers = db.prepare('SELECT id, username, role, must_change_password FROM users').all();
  console.log(newUsers);
  
  db.close();
}

createOwner().catch(console.error);
